"""Brouillon bibliographique consolidé et aperçu pseudo-UNIMARC (non conforme,
pour relecture uniquement). doc_type pilote les règles métier : code fonction
727 (thèse) vs 003 (mémoire), profil these_originale_imprimee vs
memoire_original_imprime — vérifier les deux branches à chaque modification."""

from __future__ import annotations

import html
from copy import deepcopy
from typing import Any

from config import CORPORATE_ROLE_CODES, PERSON_ROLE_CODES, ROLE_LABELS, STRONG_IDREF_STATUSES
from metadata import normalize_name_key
from render import badge, manual_idref_candidate
from state import add_event, as_json, empty_state
from step_results import record_step_result


def make_record_draft(state: dict[str, Any] | None) -> tuple[dict[str, Any], str, str, str]:
    state = deepcopy(state or empty_state())
    corrected = state.get("vlm", {}).get("corrected") or {}
    sudoc_response = state.get("sudoc", {}).get("response") or {}
    aligned = state.get("idref", {}).get("persons") or []
    doc_type = (state.get("input") or {}).get("doc_type") or "these"
    persons_by_name: dict[str, dict[str, Any]] = {}
    for item in aligned:
        response = item.get("response") or {}
        best = response.get("best_candidate") or {}
        name = item.get("name")
        if not name:
            continue
        # Un PPN validé manuellement dans l'onglet 4 vaut alignement fort, même si
        # la décision du service n'était pas « accepted ».
        manual_ppn = item.get("manual_ppn")
        service_status = response.get("status")
        if manual_ppn:
            chosen = manual_idref_candidate(item) or {}
            values = {
                "idref_ppn": manual_ppn,
                "status": f"{service_status} → validé manuellement" if service_status else "validé manuellement",
                "score": (chosen.get("score") or {}).get("final"),
                "idref_url": item.get("manual_url") or chosen.get("url"),
                "strong_idref": True,
                "manual_idref": True,
            }
        else:
            strong = service_status in STRONG_IDREF_STATUSES
            values = {
                "idref_ppn": response.get("best_ppn") if strong else None,
                "status": service_status,
                "score": (best.get("score") or {}).get("final"),
                "idref_url": best.get("url"),
                "strong_idref": strong,
                "manual_idref": False,
            }
        entry = persons_by_name.setdefault(
            normalize_name_key(name),
            {"name": name, "roles": [], "role_labels": [], **values},
        )
        for role in item.get("roles") or []:
            if role not in entry["roles"]:
                entry["roles"].append(role)
                entry["role_labels"].append(ROLE_LABELS.get(role, role))
        # Une occurrence forte écrase une entrée faible ; la validation manuelle
        # garde la priorité sur un alignement automatique.
        if values["strong_idref"] and (values["manual_idref"] or not entry.get("manual_idref")):
            entry.update(values)

    persons = list(persons_by_name.values())

    draft = {
        "profile": "memoire_original_imprime" if doc_type == "memoire" else "these_originale_imprimee",
        "work_metadata": {
            "title": corrected.get("title"),
            "subtitle": corrected.get("subtitle"),
            "language": corrected.get("language"),
            "defense_year": corrected.get("defense_year"),
            "volume": corrected.get("volume"),
        },
        "thesis_metadata": {
            "degree_type": corrected.get("degree_type"),
            "discipline": corrected.get("discipline"),
            "granting_institution": corrected.get("granting_institution"),
            "co_tutelle_institutions": corrected.get("co_tutelle_institutions") or [],
            "doctoral_school": corrected.get("doctoral_school"),
            "partner_institutions": corrected.get("partner_institutions") or [],
            "abstract": corrected.get("abstract"),
        },
        "persons": persons,
        "dewey_classification": state.get("dewey", {}).get("selected") or None,
        "sudoc_check": {
            "status": sudoc_response.get("status"),
            "duplicate_score": sudoc_response.get("duplicate_score"),
            "printed_duplicate_ppn": (sudoc_response.get("best_print_candidate") or {}).get("ppn"),
            "best_electronic_ppn": (sudoc_response.get("best_electronic_candidate") or {}).get("ppn"),
        },
    }
    state["record_draft"] = draft
    # Brouillon frais -> avis à (ré)enregistrer (nag visuel + toast d'onglet).
    state.setdefault("notes", {})["draft"] = "pending"
    record_step_result(((state.get("input") or {}).get("image_url") or "").strip(), "draft", {"draft": draft})
    state = add_event(state, "draft", "ok", "Brouillon consolidé généré.")
    return state, render_draft(draft), as_json(draft), as_json(state)


def render_draft(draft: dict[str, Any]) -> str:
    persons = draft.get("persons") or []
    person_rows = "".join(
        "<tr>"
        f"<td>{html.escape(' | '.join(person.get('role_labels') or []))}</td>"
        f"<td>{html.escape(str(person.get('name') or ''))}</td>"
        f"<td>{html.escape(str(person.get('idref_ppn') or ''))}</td>"
        f"<td>{badge(person.get('status'))}</td>"
        f"<td>{html.escape(str(person.get('score') or ''))}</td>"
        "</tr>"
        for person in persons
    )
    return f"""
    <section class="panel">
      <h3>Brouillon bibliographique consolidé</h3>
      <p><strong>Profil :</strong> <code>{html.escape(str(draft.get('profile') or ''))}</code></p>
      <p><strong>Titre :</strong> {html.escape(str((draft.get('work_metadata') or {}).get('title') or ''))}</p>
      <p><strong>Diplôme :</strong> {html.escape(str((draft.get('thesis_metadata') or {}).get('degree_type') or ''))}</p>
      <p><strong>Discipline :</strong> {html.escape(str((draft.get('thesis_metadata') or {}).get('discipline') or ''))}</p>
      <p><strong>Sudoc :</strong> {badge((draft.get('sudoc_check') or {}).get('status'))}</p>
      <table class="data-table">
        <thead><tr><th>Rôle</th><th>Nom</th><th>PPN IdRef</th><th>Statut</th><th>Score</th></tr></thead>
        <tbody>{person_rows}</tbody>
      </table>
    </section>
    <section class="panel">
      <h3>Aperçu pseudo-UNIMARC</h3>
      <pre>{html.escape(pseudo_unimarc(draft))}</pre>
      <p class="muted">Aperçu de travail uniquement. Ce n'est pas encore une sortie UNIMARC conforme.</p>
    </section>
    """


def pseudo_unimarc(draft: dict[str, Any]) -> str:
    work = draft.get("work_metadata") or {}
    thesis = draft.get("thesis_metadata") or {}
    profile = draft.get("profile") or "these_originale_imprimee"
    year = work.get("defense_year") or ""
    language = work.get("language") or "fre"
    institution = thesis.get("granting_institution") or ""
    discipline = thesis.get("discipline") or ""
    degree = thesis.get("degree_type") or ""
    dewey = draft.get("dewey_classification") or {}
    dewey_code = dewey.get("code")
    dewey_label = dewey.get("label")
    # The validated Dewey class label drives the discipline subfield in 328.
    classification_label = dewey_label or discipline
    advisors = people_with_role(draft, "advisor")
    author = first_person_with_role(draft, "author")

    lines = []
    lines.append("001  [à attribuer]")
    lines.append("008  Aax3")
    lines.append(f"029  ##$aFR")
    lines.append(f"100  ##$a{coded_100_value(year, language)}")
    lines.append(f"101  0#$a{language}")
    lines.append("102  ##$aFR")
    lines.append("106  ##$ar")
    if profile == "these_originale_imprimee":
        lines.append("104  ##$ak$by$cy$dba$e0$ffre")
        lines.append("105  ##$bm$c0$d0$fy")
    else:
        lines.append("105  ##$bv$c0$d0$fy")
    lines.append("181  ##$P01$ctxt")
    lines.append("182  ##$P01$cn")
    lines.append("183  ##$P01$anga")
    lines.append(f"200  1#$a{work.get('title') or ''}{sf('e', work.get('subtitle'))}{sf('f', author_statement(author))}{sf('g', advisor_statement(advisors))}")
    lines.append(f"214  #1$d{year}")
    # Règle v2 (schéma d'évaluation) : volume null → monovolume « 1 volume » ;
    # volume présent → la page ne donne que le n° du tome, pas le total : un
    # humain doit compléter « ? volumes ».
    volume = work.get("volume")
    lines.append("215  ##$a1 volume" if not volume else "215  ##$a? volumes")
    lines.append(f"328  #0$b{degree}$c{discipline}$e{institution}$d{year}")
    if thesis.get("abstract"):
        lines.append(f"330  ##$a{thesis.get('abstract')}")
    lines.append("608  ##$3027253139$aThèses et écrits académiques$2rameau")
    if dewey_code:
        lines.append(f"686  ##$a{dewey_code}$2TEF")

    for person in draft.get("persons") or []:
        tag = "700" if "author" in (person.get("roles") or []) else "701"
        role_codes = person_role_codes(person.get("roles") or [], profile)
        if tag == "701" and any(role in person.get("roles", []) for role in ["advisor", "jury_president", "reviewers"]):
            role_codes.append("555")
        role_codes = dedupe(role_codes)
        lines.append(f"{tag}  #1{ppn_subfield(person)}{name_subfields(person.get('name'))}{''.join(f'$4{code}' for code in role_codes)}")

    for line in corporate_lines(thesis):
        lines.append(line)
    return "\n".join(lines)


def sf(code: str, value: Any) -> str:
    return f"${code}{value}" if value else ""


def dedupe(values: list[str]) -> list[str]:
    seen = set()
    output = []
    for value in values:
        if value and value not in seen:
            seen.add(value)
            output.append(value)
    return output


def coded_100_value(year: Any, language: str) -> str:
    year_text = str(year or "uuuu")
    if len(year_text) != 4 or not year_text.isdigit():
        year_text = "uuuu"
    return f"{year_text}    k  y0{language or 'fre'}y50      ba"


def people_with_role(draft: dict[str, Any], role: str) -> list[dict[str, Any]]:
    return [person for person in draft.get("persons") or [] if role in (person.get("roles") or [])]


def first_person_with_role(draft: dict[str, Any], role: str) -> dict[str, Any] | None:
    people = people_with_role(draft, role)
    return people[0] if people else None


def author_statement(person: dict[str, Any] | None) -> str:
    return person.get("name") if person else ""


def advisor_statement(advisors: list[dict[str, Any]]) -> str:
    names = [person.get("name") for person in advisors if person.get("name")]
    if not names:
        return ""
    return "sous la direction de " + " ; ".join(names)


def person_role_codes(roles: list[str], profile: str) -> list[str]:
    advisor_code = PERSON_ROLE_CODES["advisor_dissertation"] if profile == "memoire_original_imprime" else PERSON_ROLE_CODES["advisor_thesis"]
    mapping = {
        "author": PERSON_ROLE_CODES["author"],
        "advisor": advisor_code,
        "jury_president": PERSON_ROLE_CODES["jury_president"],
        "reviewers": PERSON_ROLE_CODES["reviewers"],
        "committee_members": PERSON_ROLE_CODES["committee_members"],
    }
    return [mapping[role] for role in roles if role in mapping]


def ppn_subfield(person: dict[str, Any]) -> str:
    if person.get("strong_idref") and person.get("idref_ppn"):
        return f"$3{person.get('idref_ppn')}"
    return ""


def name_subfields(name: Any) -> str:
    text = str(name or "").strip()
    if not text:
        return "$a[Nom manquant]"
    parts = text.split()
    if len(parts) >= 2:
        return f"$a{' '.join(parts[1:])}$b{parts[0]}"
    return f"$a{text}"


def corporate_lines(thesis: dict[str, Any]) -> list[str]:
    corporates: dict[str, dict[str, Any]] = {}

    def add(name: Any, role: str) -> None:
        text = str(name or "").strip()
        if not text:
            return
        key = normalize_name_key(text)
        entry = corporates.setdefault(key, {"name": text, "roles": []})
        if role not in entry["roles"]:
            entry["roles"].append(role)

    add(thesis.get("granting_institution"), "granting_institution")
    for institution in thesis.get("co_tutelle_institutions") or []:
        add(institution, "co_tutelle_institutions")
    add(thesis.get("doctoral_school"), "doctoral_school")
    for institution in thesis.get("partner_institutions") or []:
        add(institution, "partner_institutions")

    lines = []
    for corporate in corporates.values():
        codes = [CORPORATE_ROLE_CODES[role] for role in corporate["roles"] if role in CORPORATE_ROLE_CODES]
        lines.append(f"711  02$a{corporate['name']}{''.join(f'$4{code}' for code in dedupe(codes))}")
    return lines
