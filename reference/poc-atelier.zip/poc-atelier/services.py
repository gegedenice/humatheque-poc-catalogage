"""Appels aux services métier auto-hébergés : sudoc-checker (doublons),
idref-linker Qualinka (alignement personnes) et dewey-classifier. L'app reste un
orchestrateur : aucune logique de ces services n'est réimplémentée ici."""

from __future__ import annotations

import json
from copy import deepcopy
from typing import Any

import gradio as gr
import requests

from config import EMBEDDING_MODEL
from metadata import extract_people, string_or_empty
from render import (
    pipeline_summary,
    render_dewey,
    render_idref,
    render_idref_table,
    render_sudoc,
    status_card,
    sudoc_candidate_rows,
)
from state import add_event, as_json, empty_state
from step_results import record_step_result


def _state_image_url(state: dict[str, Any]) -> str:
    return ((state.get("input") or {}).get("image_url") or "").strip()


def pipe_join(value: Any) -> str:
    """Serialize a v2 array-valued person field to the pipe-string the Sudoc
    checker API still expects (external service, unchanged)."""
    if isinstance(value, list):
        return " | ".join(str(item).strip() for item in value if str(item).strip())
    return string_or_empty(value)


def sudoc_request_payload(corrected: dict[str, Any]) -> dict[str, Any]:
    """Match the Sudoc checker schema, which expects strings for optional text fields.
    Document-kind specifics (TDO filter, NTH content filter) are not in the body:
    they are selected server-side by routing to /check/thesis or /check/dissertation.
    """
    payload = {
        "title": string_or_empty(corrected.get("title")),
        "subtitle": string_or_empty(corrected.get("subtitle")),
        "author": string_or_empty(corrected.get("author")),
        "degree_type": string_or_empty(corrected.get("degree_type")),
        "discipline": string_or_empty(corrected.get("discipline")),
        "granting_institution": string_or_empty(corrected.get("granting_institution")),
        "co_tutelle_institutions": corrected.get("co_tutelle_institutions") or [],
        "doctoral_school": string_or_empty(corrected.get("doctoral_school")),
        "defense_year": corrected.get("defense_year"),
        "advisor": pipe_join(corrected.get("advisor")),
        "jury_president": string_or_empty(corrected.get("jury_president")),
        "reviewers": pipe_join(corrected.get("reviewers")),
        "committee_members": pipe_join(corrected.get("committee_members")),
        "language": string_or_empty(corrected.get("language")),
        "confidence": corrected.get("confidence"),
    }
    if payload["defense_year"] is None:
        payload["defense_year"] = ""
    if payload["confidence"] is None:
        payload.pop("confidence")
    return payload


def sudoc_route_for(doc_type: str) -> str:
    return "/check/dissertation" if str(doc_type or "").strip().lower() == "memoire" else "/check/thesis"


def call_sudoc(state: dict[str, Any] | None, doc_type: str, api_url: str) -> tuple[dict[str, Any], str, str, list[list[Any]], str]:
    state = deepcopy(state or empty_state())
    corrected = state.get("vlm", {}).get("corrected")
    if not corrected:
        raise gr.Error("Lancez une extraction (onglet 1) puis enregistrez la validation des métadonnées (onglet 2).")
    request_payload = sudoc_request_payload(corrected)
    base_url = api_url.rstrip("/")
    route = sudoc_route_for(doc_type)
    try:
        response = requests.post(f"{base_url}{route}", headers={"Content-Type": "application/json"}, json=request_payload, timeout=None)
        response.raise_for_status()
        result = response.json()
    except requests.RequestException as exc:
        state["sudoc"]["error"] = str(exc)
        state = add_event(state, "sudoc", "error", str(exc))
        raise gr.Error(f"Erreur Sudoc: {exc}") from exc
    except ValueError as exc:
        state["sudoc"]["error"] = "Réponse Sudoc non JSON"
        state = add_event(state, "sudoc", "error", "Réponse Sudoc non JSON")
        raise gr.Error("La réponse Sudoc n'est pas un JSON valide.") from exc
    state["sudoc"] = {"request": request_payload, "route": route, "response": result, "error": None}
    # Résultat frais -> avis à (ré)enregistrer (nag visuel + toast d'onglet).
    state.setdefault("notes", {})["sudoc"] = "pending"
    record_step_result(_state_image_url(state), "sudoc", {"route": route, "request": request_payload, "response": result})
    state = add_event(state, "sudoc", "ok", f"Sudoc ({route}): {result.get('status')}")
    return state, render_sudoc(result), as_json(result), sudoc_candidate_rows(result), pipeline_summary(state)


def build_align_payload(
    extraction: dict[str, Any],
    name: str,
    use_embeddings: bool,
    weights: dict[str, float],
    params: dict[str, Any],
) -> dict[str, Any]:
    return {
        "name": name,
        "title": str(extraction.get("title") or ""),
        "subtitle": str(extraction.get("subtitle") or ""),
        "discipline": str(extraction.get("discipline") or ""),
        "institution": str(extraction.get("granting_institution") or ""),
        "doctoral_school": str(extraction.get("doctoral_school") or ""),
        "degree_type": str(extraction.get("degree_type") or ""),
        "year": str(extraction.get("defense_year") or ""),
        "max_candidates": int(params["max_candidates"]),
        "max_docs_per_role": int(params["max_docs_per_role"]),
        "reference_top_k": int(params["reference_top_k"]),
        "accept_threshold": float(params["accept_threshold"]),
        "margin_threshold": float(params["margin_threshold"]),
        "embedding_model": EMBEDDING_MODEL if use_embeddings else "",
        "weight_name": float(weights["weight_name"]),
        "weight_attrra_source": float(weights["weight_attrra_source"]),
        "weight_attrra_note": float(weights["weight_attrra_note"]),
        "weight_references": float(weights["weight_references"]),
        "weight_institution_year": float(weights["weight_institution_year"]),
    }


def call_idref_for_all(
    state: dict[str, Any] | None,
    api_url: str,
    api_key: str,
    use_embeddings: bool,
    weight_name: float,
    weight_attrra_source: float,
    weight_attrra_note: float,
    weight_references: float,
    weight_institution_year: float,
    max_candidates: int,
    max_docs_per_role: int,
    reference_top_k: int,
    accept_threshold: float,
    margin_threshold: float,
) -> tuple[dict[str, Any], str, str, str, str]:
    state = deepcopy(state or empty_state())
    corrected = state.get("vlm", {}).get("corrected")
    if not corrected:
        raise gr.Error("Lancez une extraction (onglet 1) puis enregistrez la validation des métadonnées (onglet 2).")
    people = extract_people(corrected)
    if not people:
        raise gr.Error("Aucune personne à aligner dans les métadonnées corrigées.")

    base_url = api_url.rstrip("/")
    headers = {"Content-Type": "application/json"}
    if api_key.strip():
        headers["X-API-Key"] = api_key.strip()

    weights = {
        "weight_name": weight_name,
        "weight_attrra_source": weight_attrra_source,
        "weight_attrra_note": weight_attrra_note,
        "weight_references": weight_references,
        "weight_institution_year": weight_institution_year,
    }
    params = {
        "max_candidates": max_candidates,
        "max_docs_per_role": max_docs_per_role,
        "reference_top_k": reference_top_k,
        "accept_threshold": accept_threshold,
        "margin_threshold": margin_threshold,
    }

    aligned = []
    for person in people:
        payload = build_align_payload(corrected, person["name"], use_embeddings, weights, params)
        try:
            response = requests.post(f"{base_url}/align/person", headers=headers, json=payload, timeout=None)
            response.raise_for_status()
            result = response.json()
        except requests.RequestException as exc:
            result = {"status": "error", "error": str(exc), "query": {"name": person["name"]}, "candidates": []}
        except ValueError:
            result = {"status": "error", "error": "Réponse non JSON", "query": {"name": person["name"]}, "candidates": []}
        aligned.append({"name": person["name"], "roles": person["roles"], "request": payload, "response": result})

    state["idref"] = {
        "persons": aligned,
        "settings": {"api_url": base_url, "use_embeddings": use_embeddings, "weights": weights, "params": params},
        "error": None,
    }
    state.setdefault("notes", {})["idref"] = "pending"
    record_step_result(
        _state_image_url(state), "idref",
        {"persons": aligned, "settings": state["idref"]["settings"]},
    )
    state = add_event(state, "idref", "ok", f"{len(aligned)} personne(s) alignée(s).")
    return (
        state,
        render_idref(aligned),
        as_json(aligned),
        render_idref_table(aligned=aligned),
        pipeline_summary(state),
    )


def validate_idref_ppn(
    state: dict[str, Any] | None, name: str | None, ppn: str | None
) -> tuple[dict[str, Any], str, str, str, str]:
    """Validation humaine d'un PPN pour une personne, y compris quand la décision
    du service n'est pas « accepted » (low_confidence, ambiguous, not_found…) : le
    PPN retenu est stocké sur l'entrée d'alignement (manual_ppn) et vaut alignement
    fort pour le brouillon UNIMARC (onglet 6). Déclenchée depuis le tableau
    récapitulatif (bouton « Valider » de la ligne) ou depuis un panneau candidat
    (« Retenir ce PPN »), via validate_idref_ppn_from_bridge."""
    state = deepcopy(state or empty_state())
    aligned = state.get("idref", {}).get("persons") or []
    if not aligned:
        raise gr.Error("Lancez d'abord « Aligner toutes les personnes ».")
    name = (name or "").strip()
    ppn = (ppn or "").strip()
    if not name:
        raise gr.Error("Sélectionnez la personne à valider.")
    if not ppn:
        raise gr.Error("Choisissez un PPN candidat ou saisissez-en un.")
    item = next((i for i in aligned if i.get("name") == name), None)
    if item is None:
        raise gr.Error(f"Personne absente de l'alignement : {name}")
    response = item.get("response") or {}
    candidate = next(
        (c for c in response.get("candidates") or [] if str(c.get("ppn")) == ppn), None
    )
    item["manual_ppn"] = ppn
    item["manual_url"] = (candidate or {}).get("url") or f"https://www.idref.fr/{ppn}"
    service_status = response.get("status") or "inconnue"
    # Le PPN validé fait partie du résultat durable : re-journalise l'alignement
    # complet pour que la validation manuelle survive à la session.
    record_step_result(
        _state_image_url(state), "idref",
        {"persons": aligned, "settings": state.get("idref", {}).get("settings") or {}},
    )
    state = add_event(
        state, "idref", "ok",
        f"PPN {ppn} validé manuellement pour {name} (décision du service : {service_status}).",
    )
    note = "" if candidate else " — PPN hors liste de candidats, vérifiez-le sur idref.fr"
    message = (
        f"PPN {ppn} retenu pour {name}{note}. Il sera repris comme alignement fort "
        f"dans le brouillon UNIMARC (onglet 6), malgré la décision « {service_status} »."
    )
    return (
        state,
        status_card("Validation PPN", "ok", message),
        render_idref(aligned),
        render_idref_table(aligned=aligned),
        pipeline_summary(state),
    )


def validate_idref_ppn_from_bridge(state: dict[str, Any] | None, payload: str | None):
    """Cible du pont JS IDREF_HEAD : décode le JSON {name, ppn} stashé par le
    bouton cliqué (ligne du tableau ou panneau candidat) et délègue à
    validate_idref_ppn."""
    try:
        pick = json.loads(payload or "{}")
    except ValueError:
        pick = {}
    return validate_idref_ppn(state, pick.get("name"), pick.get("ppn"))


# Pont JS de la validation manuelle IdRef, même mécanique que CORPUS_HEAD
# (corpus.py) : le tableau récapitulatif et les panneaux candidats sont du HTML
# statique qui ne peut pas déclencher d'événement Gradio. Un listener délégué
# capte les clics sur « Valider » (ligne du tableau : le PPN vient de l'input
# .idref-ppn-input de la ligne) et « Retenir ce PPN » (panneau candidat : le PPN
# vient du data-ppn du bouton), stashe {name, ppn} en JSON dans une globale JS
# et clique le bouton Gradio caché #idref_hidden_btn, dont l'event-js relit la
# globale (voir app.py). Installé via demo.launch(head=...).
IDREF_HEAD = """
<script>
(function(){
  if (window.__idrefPickInstalled) return;
  window.__idrefPickInstalled = true;
  document.addEventListener('click', function(e){
    var t = e.target;
    var btn = t && t.closest ? t.closest('.idref-validate-btn, .idref-pick-btn') : null;
    if (!btn) return;
    e.preventDefault();
    var name = btn.getAttribute('data-name') || '';
    var ppn = btn.getAttribute('data-ppn');
    if (ppn === null) {
      var row = btn.closest('tr');
      var input = row ? row.querySelector('.idref-ppn-input') : null;
      ppn = input ? input.value : '';
    }
    window.__idrefPendingPick = JSON.stringify({name: name, ppn: (ppn || '').trim()});
    var trigEl = document.querySelector('#idref_hidden_btn');
    var trigger = trigEl ? (trigEl.tagName === 'BUTTON' ? trigEl : (trigEl.querySelector('button') || trigEl)) : null;
    if (!trigger) { console.warn('[idref] trigger not found'); return; }
    trigger.click();
  }, true);
})();
</script>
"""


def build_dewey_text(corrected: dict[str, Any]) -> str:
    """Concatenate title + subtitle (when present) + discipline for the classifier."""
    parts = [
        string_or_empty(corrected.get("title")).strip(),
        string_or_empty(corrected.get("subtitle")).strip(),
        string_or_empty(corrected.get("discipline")).strip(),
    ]
    return " ".join(part for part in parts if part)


def dewey_choice_label(cls: dict[str, Any]) -> str:
    code = str(cls.get("dewey") or "")
    label = str(cls.get("label") or "")
    score = cls.get("score")
    score_text = f" — {float(score):.4f}" if isinstance(score, int | float) else ""
    return f"{code} · {label}{score_text}".strip(" ·")


def dewey_radio_update(classes: list[dict[str, Any]], selected: dict[str, Any] | None):
    choices = [(dewey_choice_label(cls), str(cls.get("dewey") or "")) for cls in classes]
    value = str(selected.get("code")) if selected and selected.get("code") is not None else None
    return gr.update(choices=choices, value=value)


def selected_from_class(cls: dict[str, Any]) -> dict[str, Any]:
    return {"code": cls.get("dewey"), "label": cls.get("label"), "score": cls.get("score")}


def call_dewey(
    state: dict[str, Any] | None,
    api_url: str,
    api_key: str,
    top_k: int,
    threshold: float,
    method: str,
) -> tuple[dict[str, Any], str, str, Any, str]:
    state = deepcopy(state or empty_state())
    corrected = state.get("vlm", {}).get("corrected")
    if not corrected:
        raise gr.Error("Lancez une extraction (onglet 1) puis enregistrez la validation des métadonnées (onglet 2).")
    text = build_dewey_text(corrected)
    if not text:
        raise gr.Error("Titre et discipline manquants pour la classification Dewey.")

    method = (method or "local").strip().lower()
    if method not in ("local", "albert"):
        raise gr.Error("Méthode de classification invalide (local ou albert).")

    request_payload = {
        "text": text,
        "classification_type": "multi-label",
        "top_k": int(top_k),
        "threshold": float(threshold),
        "method": method,
    }
    base_url = api_url.rstrip("/")
    headers = {"Content-Type": "application/json"}
    if api_key.strip():
        headers["X-API-Key"] = api_key.strip()
    try:
        response = requests.post(f"{base_url}/classify", headers=headers, json=request_payload, timeout=None)
        response.raise_for_status()
        result = response.json()
    except requests.RequestException as exc:
        state["dewey"]["error"] = str(exc)
        state = add_event(state, "dewey", "error", str(exc))
        raise gr.Error(f"Erreur Dewey: {exc}") from exc
    except ValueError as exc:
        state["dewey"]["error"] = "Réponse Dewey non JSON"
        state = add_event(state, "dewey", "error", "Réponse Dewey non JSON")
        raise gr.Error("La réponse Dewey n'est pas un JSON valide.") from exc

    classes = (((result.get("results") or [{}])[0]).get("classes")) or []
    selected = selected_from_class(classes[0]) if classes else None
    state["dewey"] = {
        "request": request_payload,
        "response": result,
        "classes": classes,
        "selected": selected,
        "error": None,
    }
    state.setdefault("notes", {})["dewey"] = "pending"
    record_step_result(
        _state_image_url(state), "dewey",
        {"request": request_payload, "response": result, "classes": classes, "selected": selected},
    )
    result_method = result.get("method") or method
    result_model = result.get("model")
    state = add_event(
        state, "dewey", "ok",
        f"{len(classes)} classe(s) Dewey proposée(s) (méthode {result_method}).",
    )
    return (
        state,
        render_dewey(classes, selected, result_method, result_model),
        as_json(result),
        dewey_radio_update(classes, selected),
        pipeline_summary(state),
    )


def select_dewey_class(state: dict[str, Any] | None, code: str | None) -> tuple[dict[str, Any], str, str]:
    state = deepcopy(state or empty_state())
    classes = state.get("dewey", {}).get("classes") or []
    if not str(code or "").strip():
        # Pas de sélection : remise à zéro / restauration programmatique du radio
        # (son .change se déclenche sans valeur) ou clic sur « Valider » sans
        # classe cochée — no-op silencieux dans les deux cas.
        return state, status_card("Classification Dewey", "idle", "En attente."), pipeline_summary(state)
    chosen = next((cls for cls in classes if str(cls.get("dewey")) == str(code)), None)
    if not chosen:
        raise gr.Error("Sélectionnez une classe Dewey valide.")
    selected = selected_from_class(chosen)
    message = f"Classe retenue : {selected['code']} — {selected['label']}"
    if state.get("dewey", {}).get("selected") == selected:
        # Sélection inchangée (change programmatique du radio après call_dewey ou
        # après restauration) : pas de nouvel événement ni de ré-journalisation.
        return state, status_card("Classification Dewey", "ok", message), pipeline_summary(state)
    state.setdefault("dewey", {})["selected"] = selected
    dewey = state["dewey"]
    record_step_result(
        _state_image_url(state), "dewey",
        {"request": dewey.get("request"), "response": dewey.get("response"), "classes": classes, "selected": selected},
    )
    state = add_event(state, "dewey", "ok", f"Classe Dewey retenue: {selected['code']} {selected['label']}")
    return state, status_card("Classification Dewey", "ok", message), pipeline_summary(state)
