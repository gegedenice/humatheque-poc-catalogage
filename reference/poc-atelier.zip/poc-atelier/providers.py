"""Fournisseurs d'inférence OpenAI-compatibles (VLM on-premise, OpenAI, Hugging
Face, Albert, LIFT, Qwen3.5 via HF Inference Providers) : résolution
endpoint/modèle/auth, préparation des images (base64 JPEG réduit) et appels
d'extraction/correction."""

from __future__ import annotations

import base64
import os
from copy import deepcopy
from io import BytesIO
from pathlib import Path
from typing import Any

import gradio as gr
import requests
from PIL import Image

from annotations import append_event
from config import (
    DEFAULT_ALBERT_MODEL,
    DEFAULT_ALBERT_URL,
    DEFAULT_HF_MODEL,
    DEFAULT_HF_URL,
    DEFAULT_LIFT_MODEL,
    DEFAULT_LIFT_URL,
    DEFAULT_OPENAI_MODEL,
    DEFAULT_OPENAI_URL,
    DEFAULT_QWEN35_MODEL,
    DEFAULT_QWEN35_URL,
    DEFAULT_VLM_MODEL,
    DEFAULT_VLM_URL,
    HF_ENDPOINTS_API_BASE,
    LIFT_ENDPOINT_NAME,
    LIFT_ENDPOINT_NAMESPACE,
    QWEN35_REQUEST_EXTRAS,
    VLM_IMAGE_JPEG_QUALITY,
    VLM_IMAGE_MAX_SIZE,
)
from metadata import metadata_to_outputs, normalize_metadata
from prompts import SYSTEM, build_eval_prompt, build_lift_prompt
from render import status_card
from state import add_event, as_json, empty_state, load_json_object


def compress_image_to_data_url(data: bytes, max_size: int = VLM_IMAGE_MAX_SIZE) -> str:
    """Downscale and JPEG-encode image bytes, returning a base64 data URI.
    Keeps the base64 path (llama.cpp may not support image URLs) but shrinks the
    payload: large scans dominate upload and inference time. Falls back to the raw
    bytes if Pillow cannot decode the image.
    """
    try:
        img = Image.open(BytesIO(data))
        img.load()
    except Exception:
        # Not a decodable image — pass the original bytes through unchanged.
        encoded = base64.b64encode(data).decode("ascii")
        return f"data:image/jpeg;base64,{encoded}"

    if img.mode not in ("RGB", "L"):
        img = img.convert("RGB")

    w, h = img.size
    ratio = min(max_size / w, max_size / h, 1.0)
    if ratio < 1:
        img = img.resize((int(w * ratio), int(h * ratio)), Image.LANCZOS)

    buf = BytesIO()
    img.save(buf, format="JPEG", quality=VLM_IMAGE_JPEG_QUALITY, optimize=True)
    encoded = base64.b64encode(buf.getvalue()).decode("ascii")
    return f"data:image/jpeg;base64,{encoded}"


def image_file_to_data_url(path: str | None, max_size: int = VLM_IMAGE_MAX_SIZE) -> str:
    if not path:
        return ""
    return compress_image_to_data_url(Path(path).read_bytes(), max_size)


def resolve_image_to_data_url(
    image_url: str | None,
    image_path: str | None,
    max_size: int = VLM_IMAGE_MAX_SIZE,
) -> str:
    raw = (image_url or "").strip()

    if not raw:
        # Fall back to local file
        return image_file_to_data_url(image_path, max_size)

    if raw.startswith("data:"):
        # Already a data URI: decode, recompress, and re-encode.
        try:
            header, _, b64 = raw.partition(",")
            if "base64" in header and b64:
                return compress_image_to_data_url(base64.b64decode(b64), max_size)
        except Exception:
            pass
        return raw

    if raw.startswith("http://") or raw.startswith("https://"):
        # Fetch on our side with a hard timeout — never let llama.cpp do this
        resp = requests.get(raw, timeout=10, allow_redirects=True)
        resp.raise_for_status()
        return compress_image_to_data_url(resp.content, max_size)

    # Assume raw base64 string without the data URI prefix
    try:
        return compress_image_to_data_url(base64.b64decode(raw), max_size)
    except Exception:
        return f"data:image/jpeg;base64,{raw}"


def resolve_vlm_provider(
    provider: str,
    vlm_endpoint: str,
    vlm_model: str,
    openai_endpoint: str,
    openai_model: str,
    hf_endpoint: str,
    hf_model: str,
    albert_endpoint: str,
    albert_model: str,
    lift_endpoint: str,
    lift_model: str,
    qwen35_endpoint: str = "",
    qwen35_model: str = "",
) -> tuple[str, str, dict[str, str]]:
    """Return (endpoint, model, auth_headers) for the selected OpenAI-compatible provider."""
    provider = str(provider or "vlm").strip().lower()
    if provider == "qwen35":
        # HF Inference Providers, routage ":fastest" — même token que le Hub.
        api_key = os.getenv("HF_TOKEN", "").strip()
        if not api_key:
            raise gr.Error("Définissez la variable d'environnement HF_TOKEN.")
        endpoint = qwen35_endpoint.strip() or DEFAULT_QWEN35_URL
        model = qwen35_model.strip() or DEFAULT_QWEN35_MODEL
        return endpoint, model, {"Authorization": f"Bearer {api_key}"}
    if provider == "openai":
        api_key = os.getenv("OPENAI_API_KEY", "").strip()
        if not api_key:
            raise gr.Error("Définissez la variable d'environnement OPENAI_API_KEY.")
        endpoint = openai_endpoint.strip() or DEFAULT_OPENAI_URL
        model = openai_model.strip() or DEFAULT_OPENAI_MODEL
        return endpoint, model, {"Authorization": f"Bearer {api_key}"}
    if provider in {"huggingface", "hf"}:
        api_key = os.getenv("HF_TOKEN", "").strip()
        if not api_key:
            raise gr.Error("Définissez la variable d'environnement HF_TOKEN.")
        endpoint = hf_endpoint.strip() or DEFAULT_HF_URL
        model = hf_model.strip() or DEFAULT_HF_MODEL
        return endpoint, model, {"Authorization": f"Bearer {api_key}"}
    if provider == "albert":
        api_key = os.getenv("ALBERT_API_KEY", "").strip()
        if not api_key:
            raise gr.Error("Définissez la variable d'environnement ALBERT_API_KEY.")
        endpoint = albert_endpoint.strip() or DEFAULT_ALBERT_URL
        model = albert_model.strip() or DEFAULT_ALBERT_MODEL
        return endpoint, model, {"Authorization": f"Bearer {api_key}"}
    if provider == "lift":
        # HF dedicated endpoint: authenticate with the same HF token.
        api_key = os.getenv("HF_TOKEN", "").strip()
        if not api_key:
            raise gr.Error("Définissez la variable d'environnement HF_TOKEN.")
        endpoint = lift_endpoint.strip() or DEFAULT_LIFT_URL
        model = lift_model.strip() or DEFAULT_LIFT_MODEL
        return endpoint, model, {"Authorization": f"Bearer {api_key}"}
    endpoint = vlm_endpoint.strip() or DEFAULT_VLM_URL
    model = vlm_model.strip() or DEFAULT_VLM_MODEL
    return endpoint, model, {}


def call_vlm(
    state: dict[str, Any] | None,
    annotator: str,
    doc_type: str,
    image_url: str,
    prompt: str,
    provider: str,
    vlm_endpoint: str,
    vlm_model: str,
    openai_endpoint: str,
    openai_model: str,
    hf_endpoint: str,
    hf_model: str,
    albert_endpoint: str,
    albert_model: str,
    lift_endpoint: str,
    lift_model: str,
    qwen35_endpoint: str,
    qwen35_model: str,
    image_max_size: int,
) -> tuple[Any, ...]:
    state = deepcopy(state or empty_state())
    provider_norm = str(provider or "vlm").strip().lower()
    resolved_image_url = resolve_image_to_data_url(image_url, None, int(image_max_size))
    if not resolved_image_url:
        raise gr.Error("Renseignez une URL d'image.")
    if not prompt.strip():
        prompt = build_lift_prompt(doc_type) if provider_norm == "lift" else build_eval_prompt(doc_type)

    endpoint, model, auth_headers = resolve_vlm_provider(
        provider, vlm_endpoint, vlm_model, openai_endpoint, openai_model,
        hf_endpoint, hf_model, albert_endpoint, albert_model, lift_endpoint, lift_model,
        qwen35_endpoint, qwen35_model,
    )

    payload = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": resolved_image_url}},
                ],
            }
        ],
        "response_format": {"type": "json_object"},
    }
    if provider_norm == "qwen35":
        # Thinking désactivé + paramètres d'échantillonnage recommandés (config.py).
        payload.update(deepcopy(QWEN35_REQUEST_EXTRAS))
    try:
        response = requests.post(
            endpoint.strip(),
            headers={"Content-Type": "application/json", **auth_headers},
            json=payload,
            timeout=None,
        )
        response.raise_for_status()
        raw_response = response.json()
    except requests.RequestException as exc:
        state["vlm"]["error"] = str(exc)
        state = add_event(state, "vlm", "error", str(exc))
        status_code = getattr(getattr(exc, "response", None), "status_code", None)
        if provider_norm == "lift" and status_code == 503:
            # Endpoint scale-to-zero endormi : ce 503 vient de déclencher son
            # redémarrage — inutile de marteler, il faut juste attendre.
            raise gr.Error(
                "Endpoint LIFT en veille (503) : cet appel vient de déclencher son "
                "redémarrage. Patientez 2 à 5 min — suivez l'état avec « Vérifier le "
                "statut » dans le panneau du fournisseur, puis relancez l'extraction."
            ) from exc
        raise gr.Error(f"Erreur VLM: {exc}") from exc
    except ValueError as exc:
        state["vlm"]["error"] = "Réponse VLM non JSON"
        state = add_event(state, "vlm", "error", "Réponse VLM non JSON")
        raise gr.Error("La réponse VLM n'est pas un JSON valide.") from exc

    content = (((raw_response.get("choices") or [{}])[0].get("message") or {}).get("content") or "").strip()
    extracted = load_json_object(content, "Contenu JSON du VLM")
    normalized = normalize_metadata(extracted)

    state["input"] = {
        "doc_type": doc_type,
        "image_url": image_url.strip(),
        "image_filename": "",
        "provider": str(provider or "vlm").strip().lower(),
        "endpoint": endpoint,
        "model": model,
    }
    state["vlm"] = {"request": payload, "raw_response": raw_response, "extracted": extracted, "corrected": normalized, "error": None}
    # Nouvelle extraction -> la validation (onglet 2) est à (re)faire.
    state.setdefault("notes", {})["vlm"] = "pending"
    state = add_event(state, "vlm", "ok", "Extraction VLM terminée.")

    # Log the raw extraction to the shared annotation store so the corpus dashboard
    # can flag this image as "seen". Only rows with a real image URL are trackable.
    image_url_clean = image_url.strip()
    if image_url_clean:
        append_event({
            "annotator": (annotator or "").strip(),
            "image_url": image_url_clean,
            "action": "extract",
            "doc_type": doc_type,
            "provider": provider_norm,
            "model": model,
            "prompt": prompt,
            "raw_json": extracted,
        })

    return state, as_json(extracted), as_json(raw_response), status_card("Extraction VLM", "ok", "Métadonnées extraites."), *metadata_to_outputs(normalized)


# --------------------------------------------------------------------------
# Cycle de vie de l'endpoint HF dédié LIFT (scale-to-zero après 30 min
# d'inactivité). L'API de gestion (api.endpoints.huggingface.cloud) expose
# l'état (`status.state`) et POST /resume pour un endpoint en pause ; un
# endpoint `scaledToZero` se réveille dès qu'une requête atteint son URL.
# --------------------------------------------------------------------------

# Libellé français + tonalité de status_card, par état de l'API de gestion.
LIFT_ENDPOINT_STATES = {
    "running": ("ok", "Endpoint en ligne — prêt pour l'inférence."),
    "scaledToZero": ("warn", "Endpoint en veille (scale-to-zero après 30 min d'inactivité). Cliquez « Réveiller l'endpoint » puis attendez 2 à 5 min."),
    "paused": ("warn", "Endpoint en pause (arrêt manuel). Cliquez « Réveiller l'endpoint » pour le relancer."),
    "initializing": ("warn", "Endpoint en cours de démarrage — l'inférence sera disponible dans 2 à 5 min. Re-vérifiez le statut avant de lancer l'extraction."),
    "pending": ("warn", "Endpoint en attente de ressources — démarrage imminent."),
    "updating": ("warn", "Endpoint en cours de mise à jour."),
    "updateFailed": ("error", "Échec de mise à jour de l'endpoint — vérifiez sa configuration sur ui.endpoints.huggingface.co."),
    "failed": ("error", "Endpoint en échec — vérifiez ses logs sur ui.endpoints.huggingface.co."),
}


def _lift_endpoint_api_url() -> str:
    return f"{HF_ENDPOINTS_API_BASE.rstrip('/')}/{LIFT_ENDPOINT_NAMESPACE}/{LIFT_ENDPOINT_NAME}"


def _hf_token_or_error() -> str:
    token = os.getenv("HF_TOKEN", "").strip()
    if not token:
        raise gr.Error("Définissez la variable d'environnement HF_TOKEN (statut de l'endpoint LIFT).")
    return token


def fetch_lift_endpoint_info() -> dict[str, Any]:
    """GET the managed-endpoint description (state, replicas, url) from the
    HF Inference Endpoints management API."""
    token = _hf_token_or_error()
    response = requests.get(
        _lift_endpoint_api_url(),
        headers={"Authorization": f"Bearer {token}"},
        timeout=15,
    )
    response.raise_for_status()
    return response.json()


def lift_endpoint_status_card(info: dict[str, Any]) -> str:
    status = info.get("status") or {}
    state = str(status.get("state") or "inconnu")
    tone, label = LIFT_ENDPOINT_STATES.get(state, ("idle", f"État : {state}."))
    ready = status.get("readyReplica")
    target = status.get("targetReplica")
    replicas = ""
    if ready is not None and target is not None:
        replicas = f" Réplicas prêts : {ready}/{target}."
    return status_card(
        f"Endpoint LIFT ({LIFT_ENDPOINT_NAMESPACE}/{LIFT_ENDPOINT_NAME})",
        tone,
        f"État « {state} » — {label}{replicas}",
    )


def check_lift_endpoint() -> str:
    """Handler du bouton « Vérifier le statut » (et de l'auto-refresh au passage
    sur le fournisseur lift)."""
    try:
        info = fetch_lift_endpoint_info()
    except requests.RequestException as exc:
        return status_card("Endpoint LIFT", "error", f"Impossible d'interroger l'API de gestion : {exc}")
    return lift_endpoint_status_card(info)


def wake_lift_endpoint() -> str:
    """Handler du bouton « Réveiller l'endpoint » : POST /resume si l'endpoint
    est en pause ; simple requête sur /health si scale-to-zero (c'est la requête
    elle-même qui déclenche le redémarrage). Sans effet s'il tourne déjà."""
    token = _hf_token_or_error()
    try:
        info = fetch_lift_endpoint_info()
    except requests.RequestException as exc:
        return status_card("Endpoint LIFT", "error", f"Impossible d'interroger l'API de gestion : {exc}")
    status = info.get("status") or {}
    state = str(status.get("state") or "")
    if state == "running":
        return lift_endpoint_status_card(info)
    if state == "paused":
        try:
            response = requests.post(
                f"{_lift_endpoint_api_url()}/resume",
                headers={"Authorization": f"Bearer {token}"},
                timeout=15,
            )
            response.raise_for_status()
        except requests.RequestException as exc:
            return status_card("Endpoint LIFT", "error", f"Échec du resume : {exc}")
    else:
        # scaledToZero (ou état transitoire) : toucher l'endpoint suffit à lancer
        # le redémarrage — le 503 renvoyé pendant l'initialisation est attendu.
        endpoint_url = str(status.get("url") or "").rstrip("/")
        if endpoint_url:
            try:
                requests.get(
                    f"{endpoint_url}{info.get('healthRoute') or '/health'}",
                    headers={"Authorization": f"Bearer {token}"},
                    timeout=10,
                )
            except requests.RequestException:
                pass
    return status_card(
        f"Endpoint LIFT ({LIFT_ENDPOINT_NAMESPACE}/{LIFT_ENDPOINT_NAME})",
        "warn",
        "Redémarrage déclenché — comptez 2 à 5 min avant que l'inférence réponde. "
        "Cliquez « Vérifier le statut » pour suivre le démarrage (état « running » = prêt).",
    )


def refresh_lift_status_on_provider(provider: str):
    """Chaîné sur le changement de fournisseur (onglet 1) : rafraîchit le statut
    seulement quand lift est sélectionné, sans requête réseau sinon."""
    if str(provider or "").strip().lower() == "lift":
        return check_lift_endpoint()
    return gr.update()


CORRECTION_PROVIDERS = {"openai", "huggingface", "hf", "albert"}


def call_correction_llm(
    state: dict[str, Any] | None,
    provider: str,
    openai_endpoint: str,
    openai_model: str,
    hf_endpoint: str,
    hf_model: str,
    albert_endpoint: str,
    albert_model: str,
    image_max_size: int,
) -> tuple[Any, ...]:
    """Génération de données synthétiques (onglet 2) : ré-extraction de l'image par un
    LLM hébergé (OpenAI / Hugging Face / Albert) guidé par le message système SYSTEM,
    pour proposer une correction que l'humain relit puis valide. Ne touche ni à
    l'extraction brute (state["vlm"]["extracted"]) ni au journal d'annotations : la
    provenance part dans l'événement `validate` via save_vlm_verdict."""
    state = deepcopy(state or empty_state())
    provider_norm = str(provider or "").strip().lower()
    if provider_norm not in CORRECTION_PROVIDERS:
        raise gr.Error("Choisissez un fournisseur de correction (OpenAI, Hugging Face ou Albert).")
    inp = state.get("input") or {}
    image_url = (inp.get("image_url") or "").strip()
    doc_type = inp.get("doc_type") or "these"
    if not image_url:
        raise gr.Error("Lancez d'abord une extraction VLM (onglet 1) : l'image et le type de document en proviennent.")
    resolved_image_url = resolve_image_to_data_url(image_url, None, int(image_max_size))

    prompt = build_eval_prompt(doc_type)
    endpoint, model, auth_headers = resolve_vlm_provider(
        provider_norm, "", "", openai_endpoint, openai_model,
        hf_endpoint, hf_model, albert_endpoint, albert_model, "", ""
    )

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": SYSTEM},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": resolved_image_url}},
                ],
            },
        ],
        "response_format": {"type": "json_object"},
    }
    try:
        response = requests.post(
            endpoint.strip(),
            headers={"Content-Type": "application/json", **auth_headers},
            json=payload,
            timeout=None,
        )
        response.raise_for_status()
        raw_response = response.json()
    except requests.RequestException as exc:
        state["vlm"]["correction"] = {"provider": provider_norm, "model": model, "error": str(exc)}
        state = add_event(state, "metadata", "error", str(exc))
        raise gr.Error(f"Erreur correction LLM: {exc}") from exc
    except ValueError as exc:
        state["vlm"]["correction"] = {"provider": provider_norm, "model": model, "error": "Réponse non JSON"}
        state = add_event(state, "metadata", "error", "Réponse correction LLM non JSON")
        raise gr.Error("La réponse du LLM de correction n'est pas un JSON valide.") from exc

    content = (((raw_response.get("choices") or [{}])[0].get("message") or {}).get("content") or "").strip()
    extracted = load_json_object(content, "Contenu JSON de la correction LLM")
    normalized = normalize_metadata(extracted)

    state["vlm"]["corrected"] = normalized
    state["vlm"]["correction"] = {"provider": provider_norm, "model": model, "raw": extracted, "error": None}
    state = add_event(state, "metadata", "ok", f"Correction synthétique générée par {model}.")
    return (
        state,
        status_card(
            "Correction LLM",
            "ok",
            f"Correction synthétique générée par {model}. Relisez les champs puis cliquez « Valider les métadonnées corrigées ».",
        ),
        *metadata_to_outputs(normalized),
    )
