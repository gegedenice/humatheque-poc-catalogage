"""Prompts d'extraction (logique métier), schéma v2 harmonisé avec
humatheque-vlm-evaluation : 16 champs (dont `volume`), champs multivalués
TOUJOURS en tableaux JSON ([] si vide), scalaires à null, inférence autorisée
pour la seule `discipline`. Toute évolution du schéma passe aussi par
normalize_metadata, les sorties du formulaire, la projection SFT/DPO et les
rendus brouillon/UNIMARC (voir CLAUDE.md)."""

from __future__ import annotations

import json
from typing import Any

from config import DISSERTATION_DEGREE_TYPE_VALUES, THESIS_DEGREE_TYPE_VALUES


# Message système pour la correction assistée par LLM (onglet 2) : génération de
# données synthétiques revues par l'humain avant validation.
SYSTEM = (
    "You are a meticulous library cataloguing assistant. You extract metadata strictly "
    "from what is visually present on the page. Output only the requested JSON object."
)


def _doc_type_parts(doc_type: str) -> tuple[list[str], str]:
    doc_type_norm = str(doc_type or "").strip().lower()
    if doc_type_norm == "memoire":
        return DISSERTATION_DEGREE_TYPE_VALUES, "graduate dissertation"
    return THESIS_DEGREE_TYPE_VALUES, "graduate thesis"


def build_eval_prompt(doc_type: str) -> str:
    """Prompt v2, verbatim depuis prompts/{thesis,dissertation}.txt du projet
    d'évaluation (seuls le label de document et le vocabulaire degree_type
    changent selon doc_type)."""
    degree_type_values, document_label = _doc_type_parts(doc_type)
    degree_type_str = " | ".join(degree_type_values)
    return f"""You are extracting metadata from a French {document_label} title page.
General rules:
- Return ONLY valid JSON.
- Do not add markdown.
- Do not add explanations.
- Do not invent missing data.
- Multivalued fields are always JSON arrays; use [] when empty. Scalar fields use null when absent.
- If source text is written in all-caps, transform it into sentence case with French accents.
- For person names, apply sentence case (e.g. Jean-Daniel DUBOIS → Jean-Daniel Dubois, MARIE-FRANCE Dupont → Marie-France Dupont) and remove all civility and title prefixes (e.g. Monsieur, Madame, M., Mme, Professeur, Pr, Dr, etc.) before returning the name.
Role attribution rules:
- A role is explicit only when a textual role label is directly associated with the person.
- Assign a person to a specific role ONLY if that role is explicitly written on the title page.
- Do NOT infer roles from position, ordering, typography, academic conventions, or prior knowledge.
- Do not infer role equivalence from document structure or visual grouping.
- If people are listed without explicit role labels, place them ONLY in committee_members.
- If no jury or committee members are explicitly listed, use [].
- Do NOT guess who is advisor, reviewer, or jury president.
{{
  "title": "Main title as it appears on the title page",
  "subtitle": "Subtitle or remainder of the title, usually following a colon.",
  "author": "Full name of the author (student) who wrote the {document_label}",
  "degree_type": "Academic degree sought by the author. Possible values are {degree_type_str}",
  "discipline": "Academic field or discipline of the {document_label} as explicitly mentioned. If not explicitly mentioned, infer it from the title and any other visible contextual elements (this is the only field where inference is allowed). Always return the discipline label in French (e.g. Histoire, Droit public, Sciences de l'éducation).",
  "volume": "Volume number if the title page explicitly mentions a volume, returned as the Arabic numeral only (e.g. \\"1\\" when the page prints Tome 1, TOME PREMIER or vol. I). Null if not explicitly mentioned.",
  "granting_institution": "Institution where the {document_label} was submitted and the degree is granted",
  "co_tutelle_institutions": "List of institutions involved in a joint supervision or co-tutelle agreement.",
  "doctoral_school": "Doctoral school or graduate program, if explicitly mentioned",
  "defense_year": "Year the {document_label} was defended. Format yyyy",
  "advisor": "List of ONLY persons explicitly identified as {document_label} advisor/supervisor/director.",
  "jury_president": "ONLY the person explicitly identified as president/chair of the jury. Null if not explicitly stated.",
  "reviewers": "List of ONLY official reviewers/rapporteurs explicitly identified as such.",
  "committee_members": "List of persons explicitly listed as jury or committee members whose role is not explicitly identified as president/chair or reviewer/rapporteur. Include unlabeled persons here.",
  "language": "Language in ISO 639-3 codes. Example: fre, eng, ita...",
  "confidence": "Confidence score between 0.0 and 1.0 reflecting certainty based only on explicitly visible evidence on the page"
}}"""


def build_lift_prompt(doc_type: str) -> str:
    """Prompt for the datalab-to/lift model, which enforces a strict JSON schema and
    is prompted differently from the on-prem VLM: a schema-driven extraction template
    (v2: per-field descriptions from the eval project's strict.py, plus the general
    and role rules as extra Instructions bullets)."""
    degree_type_values, document_label = _doc_type_parts(doc_type)
    degree_type_str = " | ".join(degree_type_values)
    strip_prefixes = (
        "Apply sentence case and remove all civility/title prefixes (Monsieur, Madame, "
        "M., Mme, Professeur, Pr, Dr, etc.)."
    )
    schema = {
        "type": "object",
        "properties": {
            "title": {"type": "string", "description": "Main title as it appears on the title page"},
            "subtitle": {"type": "string", "description": "Subtitle or remainder of the title, usually following a colon. Null if not present."},
            "author": {"type": "string", "description": f"Full name of the author (student) who wrote the {document_label}. {strip_prefixes}"},
            "degree_type": {"type": "string", "enum": list(degree_type_values), "description": f"Academic degree sought by the author. Possible values are {degree_type_str}"},
            "discipline": {"type": "string", "description": f"Academic field or discipline of the {document_label} as explicitly mentioned. If not explicitly mentioned, infer it from the title and any other visible contextual elements (this is the only field where inference is allowed). Always return the discipline label in French (e.g. Histoire, Droit public, Sciences de l'éducation)."},
            "volume": {"type": "string", "description": "Volume number if the title page explicitly mentions a volume, returned as the Arabic numeral only (e.g. \"1\" when the page prints Tome 1, TOME PREMIER or vol. I). Null if not explicitly mentioned."},
            "granting_institution": {"type": "string", "description": f"Institution where the {document_label} was submitted and the degree is granted"},
            "co_tutelle_institutions": {"type": "array", "items": {"type": "string"}, "description": "List of institutions involved in a joint supervision or co-tutelle agreement. Empty array if none."},
            "doctoral_school": {"type": "string", "description": "Doctoral school or graduate program, if explicitly mentioned"},
            "defense_year": {"type": "integer", "description": f"Year the {document_label} was defended. Format yyyy"},
            "advisor": {"type": "array", "items": {"type": "string"}, "description": f"List of ONLY persons explicitly identified as {document_label} advisor/supervisor/director. Empty array if the role is not explicitly stated."},
            "jury_president": {"type": "string", "description": "ONLY the person explicitly identified as president/chair of the jury. Null if not explicitly stated."},
            "reviewers": {"type": "array", "items": {"type": "string"}, "description": "List of ONLY official reviewers/rapporteurs explicitly identified as such. Empty array if not explicitly stated."},
            "committee_members": {"type": "array", "items": {"type": "string"}, "description": "List of persons explicitly listed as jury or committee members whose role is not explicitly identified as president/chair or reviewer/rapporteur. Include unlabeled persons here. Empty array if none."},
            "language": {"type": "string", "description": "Language in ISO 639-3 codes. Example: fre, eng, ita..."},
        },
    }
    schema_json = json.dumps(schema, ensure_ascii=False, indent=2)
    return f"""Extract structured data from this document according to the provided JSON schema.  The document is provided as images, in page order.

## JSON Schema
```json
{schema_json}
```

## Instructions
- Return a JSON object matching the schema
- Use the correct type for each field (string, number, array)
- Do not invent missing data. Multivalued fields are always JSON arrays; use [] when empty. Scalar fields use null when absent.
- If source text is written in all-caps, transform it into sentence case with French accents.
- For person names, apply sentence case (e.g. Jean-Daniel DUBOIS → Jean-Daniel Dubois) and remove all civility and title prefixes (Monsieur, Madame, M., Mme, Professeur, Pr, Dr, etc.).
- A role is explicit only when a textual role label is directly associated with the person. Do NOT infer roles from position, ordering, typography, academic conventions, or prior knowledge. If people are listed without explicit role labels, place them ONLY in committee_members."""


# --------------------------------------------------------------------------
# SFT dataset builders. A validated (OK) VLM extraction becomes training rows in
# three chat-messages flavours so the same corpus can fine-tune any of the three
# candidate targets, each with its own prompt convention:
#   - "classic"   : build_eval_prompt (v2, arrays for multivalued fields).
#   - "lift"      : build_lift_prompt (datalab-to/lift), JSON Schema in prompt.
#   - "nuextract" : NuExtract3 JSON-template + free-text instructions.
# The human-validated ("corrected") JSON is the target; the model's self-reported
# `confidence` is dropped (it is not ground truth).
# --------------------------------------------------------------------------

# v2: aligné sur strict.py du projet d'évaluation (règles générales + rôles,
# exception d'inférence pour discipline, règle volume en chiffres arabes).
NUEXTRACT_INSTRUCTIONS = (
    "Extract only what is explicitly visible on the title page; do not invent missing data "
    "and do not infer roles from position, ordering, typography, or academic convention. "
    "Multivalued fields are always arrays: use [] when empty; use null for absent scalar fields. "
    "If source text is all-caps, transform it to sentence case with French accents. "
    "For person names, apply sentence case and remove civility/title prefixes "
    "(Monsieur, Madame, M., Mme, Professeur, Pr, Dr, etc.). "
    "A role is explicit only when a textual role label is directly associated with the person. "
    "If people are listed without an explicit role label, place them ONLY in committee_members. "
    "Exception for discipline: if not explicitly mentioned, infer it from the title and visible "
    "context, and always return the label in French (e.g. Histoire, Droit public, Sciences de "
    "l'éducation). volume is the volume number when the page explicitly mentions a volume, "
    "returned as the Arabic numeral only (e.g. \"1\" for Tome 1 or vol. I); null otherwise."
)


def build_nuextract_template(doc_type: str) -> dict[str, Any]:
    """Return {"template": <json str>, "instructions": <str>} for NuExtract3.
    The template's degree_type enum switches on doc_type; instructions are shared.
    v2: title/subtitle are plain "string" (the all-caps -> sentence-case rule mandates
    a transformation, which "verbatim-string" would forbid); `volume` added."""
    degree_values, _ = _doc_type_parts(doc_type)
    template = {
        "title": "string",
        "subtitle": "string",
        "author": "string",
        "degree_type": list(degree_values),
        "discipline": "string",
        "volume": "string",
        "granting_institution": "string",
        "co_tutelle_institutions": ["string"],
        "doctoral_school": "string",
        "defense_year": "integer",
        "advisor": ["string"],
        "jury_president": "string",
        "reviewers": ["string"],
        "committee_members": ["string"],
        "language": "string",
    }
    return {
        "template": json.dumps(template, ensure_ascii=False, indent=2),
        "instructions": NUEXTRACT_INSTRUCTIONS,
    }
