from __future__ import annotations

import os
from functools import partial

import gradio as gr

from annotations import note_pending_updates, save_step_note, validate_extraction, warn_pending_notes
from config import (
    DEFAULT_ALBERT_MODEL,
    DEFAULT_ALBERT_URL,
    DEFAULT_ANNOTATOR,
    DEFAULT_DEWEY_API_KEY,
    DEFAULT_DEWEY_URL,
    DEFAULT_HF_DATASET_REPO,
    DEFAULT_HF_MODEL,
    DEFAULT_HF_URL,
    DEFAULT_IDREF_ACCEPT_THRESHOLD,
    DEFAULT_IDREF_API_KEY,
    DEFAULT_IDREF_MARGIN_THRESHOLD,
    DEFAULT_IDREF_MAX_CANDIDATES,
    DEFAULT_IDREF_MAX_DOCS_PER_ROLE,
    DEFAULT_IDREF_REFERENCE_TOP_K,
    DEFAULT_IDREF_URL,
    DEFAULT_LIFT_MODEL,
    DEFAULT_LIFT_URL,
    DEFAULT_OPENAI_MODEL,
    DEFAULT_OPENAI_URL,
    DEFAULT_QWEN35_MODEL,
    DEFAULT_QWEN35_URL,
    DEFAULT_SUDOC_URL,
    DEFAULT_VLM_MODEL,
    DEFAULT_VLM_URL,
    DEFAULT_WEIGHT_ATTRRA_NOTE,
    DEFAULT_WEIGHT_ATTRRA_SOURCE,
    DEFAULT_WEIGHT_INSTITUTION_YEAR,
    DEFAULT_WEIGHT_NAME,
    DEFAULT_WEIGHT_REFERENCES,
    EMBEDDING_MODEL,
    EXAMPLE_IMAGE_URL,
    EXPORT_IMAGE_MAX_SIZE,
    HF_MODEL_CHOICES,
    VLM_IMAGE_MAX_SIZE,
)
from corpus import (
    CORPUS_FILTER_CHOICES,
    CORPUS_GALLERY_CAP,
    CORPUS_HEAD,
    RESUME_OUTPUT_ORDER,
    build_corpus_gallery,
    corpus_counters_html,
    load_picked_url,
    load_url_from_corpus,
    refresh_corpus,
)
from dataset_export import EXPORT_FORMATS, preview_export, push_export_to_hub
from metadata import update_corrected_metadata
from prompts import build_eval_prompt, build_lift_prompt
from providers import (
    call_correction_llm,
    call_vlm,
    check_lift_endpoint,
    refresh_lift_status_on_provider,
    wake_lift_endpoint,
)
from render import CSS, pipeline_summary, render_idref_table, render_image_preview, status_card
from services import (
    IDREF_HEAD,
    call_dewey,
    call_idref_for_all,
    call_sudoc,
    select_dewey_class,
    validate_idref_ppn_from_bridge,
)
from specs import (
    SPEC_PRIORITY_CHOICES,
    SPEC_PRODUCTION_MODES,
    SPEC_STATUS_CHOICES,
    export_spec,
    fold_spec,
    render_spec_field,
    render_spec_table,
    save_spec_revision,
    select_spec_field,
    spec_counters_html,
    spec_field_choices,
    spec_form_values,
    zones_from_unimarc_text,
)
from state import empty_state
from unimarc import make_record_draft, pseudo_unimarc


def notation_widget(title: str):
    """Build the collaborative OK/KO + remark block for a pipeline step and
    return its components (verdict, remark, button, status) for wiring."""
    with gr.Group():
        gr.Markdown(f"#### Notation collaborative — {title}")
        with gr.Row():
            verdict = gr.Radio([("OK", "ok"), ("KO", "ko")], value="ok", label="Avis", scale=2)
            remark = gr.Textbox(label="Remarque (optionnelle)", scale=3)
        button = gr.Button(f"Enregistrer l'avis {title}", variant="secondary")
        status = gr.HTML(status_card(f"Notation {title}", "idle", "En attente."))
    return verdict, remark, button, status


def refresh_spec_view(field_id: str | None, state: dict | None):
    """Re-fold the spec store and refresh counters/table/selector/panel + the
    revision form (re-filled with the folded values of the selected zone). The
    selector also picks up the zones present in the current generated draft, so a
    field can be specified in the context of a concrete example."""
    records = fold_spec()
    draft = (state or {}).get("record_draft")
    zones = zones_from_unimarc_text(pseudo_unimarc(draft)) if draft else []
    return (
        spec_counters_html(records),
        render_spec_table(records),
        gr.update(choices=spec_field_choices(records, zones)),
        render_spec_field(field_id, records),
        *spec_form_values(field_id, records),
    )


with gr.Blocks(title="Humatheque Pipeline POC Atelier") as demo:
    state = gr.State(empty_state())

    gr.Markdown("# Humatheque Pipeline POC Atelier \nImage de page de titre \n-> extraction VLM + notation + datasets de fine-tuning \n-> vérification Sudoc + notation\n-> alignement IdRef + notation\n-> classification Dewey + notation\n-> brouillon Unimarc + notation\n-> Spécifications Unimarc\n-> Export datasets sur HuggingFace.")
    with gr.Row():
        annotator = gr.Textbox(
            value=DEFAULT_ANNOTATOR,
            label="Annotateur",
            placeholder="Votre nom (associé à chaque avis et validation)",
            scale=3,
        )
    summary = gr.HTML(pipeline_summary(empty_state()))

    with gr.Tab("Corpus / Dataset") as corpus_tab:
        gr.Markdown(
            "Une page est **traitée** dès qu'une validation est enregistrée "
            "dans l'onglet « 2. Métadonnées corrigées » ; la colonne **DPO** indique alors "
            "si la correction a produit une paire DPO. Les colonnes **Sudoc / IdRef / "
            "Dewey / Brouillon Unimarc** (onglets 3 à 6) reprennent l'avis OK/KO noté sur chaque étape. "
            "Cliquez **Charger** sur une ligne pour envoyer son "
            "URL vers l'onglet « 1. Extraction VLM » : l'avancement déjà journalisé est **restauré** "
            ": extraction, métadonnées validées et avis, mais aussi les **derniers "
            "résultats Sudoc / IdRef (PPN validés compris) / Dewey / brouillon** "
            "(journal `step_results.jsonl`). Vous reprenez le document là où il "
            "s'était arrêté, sans refaire l'extraction ni rappeler les API."
        )
        corpus_counters = gr.HTML(corpus_counters_html())
        with gr.Row():
            corpus_filter = gr.Radio(CORPUS_FILTER_CHOICES, value="tous", label="Filtrer par statut", scale=4)
            corpus_refresh_btn = gr.Button("Rafraîchir", scale=1)
        corpus_select_status = gr.HTML(status_card("Sélection corpus", "idle", "Aucune sélection."))
        corpus_url_state = gr.State([])
        # Hidden bridge: each "Charger" button in the HTML table stashes its URL in
        # window.__corpusPendingUrl and clicks corpus_hidden_btn (see CORPUS_HEAD).
        # The trigger's .click has a `js` that returns [window.__corpusPendingUrl];
        # Gradio replaces the input value(s) with that array, so load_picked_url is
        # called with the URL directly (no fragile textbox value-sync). corpus_hidden_url
        # is only the required 1-slot input placeholder (its real value is ignored).
        # Both must stay MOUNTED (visible=False unmounts them), so hidden via CSS.
        corpus_hidden_url = gr.Textbox(elem_id="corpus_hidden_url", elem_classes=["corpus-bridge"])
        corpus_hidden_btn = gr.Button("charger", elem_id="corpus_hidden_btn", elem_classes=["corpus-bridge"])
        corpus_table_html = gr.HTML()
        corpus_gallery_btn = gr.Button(f"Afficher les vignettes (max {CORPUS_GALLERY_CAP})", scale=1)
        corpus_gallery = gr.Gallery(
            label=f"Vignettes (max {CORPUS_GALLERY_CAP}, chargées à la demande)",
            columns=6,
            height=360,
            preview=False,
        )

    with gr.Tab("1. Extraction VLM"):
        with gr.Row():
            with gr.Column(scale=2):
                doc_type = gr.Radio([("Thèse", "these"), ("Mémoire / dissertation", "memoire")], value="these", label="Type de document")
                image_url = gr.Textbox(value=EXAMPLE_IMAGE_URL, label="URL d'image")
                url_preview = gr.HTML(render_image_preview(EXAMPLE_IMAGE_URL))
                prompt = gr.Code(value=build_eval_prompt("these"), language="markdown", label="Prompt VLM", lines=18)
            with gr.Column(scale=1):
                vlm_provider = gr.Radio(
                    [
                        ("datalab-to/lift (Q8 GGUF, HF dedicated endpoint)", "lift"),
                        ("Qwen/Qwen3.5-9B (HF Inference Providers, provider auto fastest)", "qwen35"),
                    ],
                    value="qwen35",
                    label="Fournisseur d'inférence",
                )
                # Fournisseur on-premise retiré de l'UI mais toujours supporté par
                # resolve_vlm_provider/call_vlm : ses champs restent montés (cachés)
                # car ils sont des inputs positionnels de call_vlm.
                with gr.Group(visible=False) as vlm_group:
                    vlm_endpoint = gr.Textbox(value=DEFAULT_VLM_URL, label="Endpoint VLM on-premise")
                    vlm_model = gr.Textbox(value=DEFAULT_VLM_MODEL, label="Modèle VLM on-premise")
                with gr.Group(visible=False) as lift_group:
                    lift_endpoint = gr.Textbox(value=DEFAULT_LIFT_URL, label="Endpoint LIFT")
                    lift_model = gr.Textbox(value=DEFAULT_LIFT_MODEL, label="Modèle LIFT")
                    # L'endpoint dédié est en scale-to-zero (arrêt après 30 min
                    # d'inactivité) : sans ce panneau, un 503 au réveil est opaque.
                    lift_ep_status = gr.HTML(status_card("Endpoint LIFT", "idle", "Statut inconnu — cliquez « Vérifier le statut »."))
                    with gr.Row():
                        lift_ep_check_btn = gr.Button("Vérifier le statut", scale=1)
                        lift_ep_wake_btn = gr.Button("Réveiller l'endpoint", variant="secondary", scale=1)
                with gr.Group(visible=True) as qwen35_group:
                    qwen35_endpoint = gr.Textbox(value=DEFAULT_QWEN35_URL, label="Endpoint HF Inference Providers")
                    qwen35_model = gr.Textbox(value=DEFAULT_QWEN35_MODEL, label="Modèle (suffixe :fastest = provider le plus rapide)")
                gr.Markdown(
                    "L'endpoint Hugging Face dédié pour lift est **mis en veille après 30 min "
                    "d'inactivité**; Vérifiez son statut ci-dessus et réveillez-le au "
                    "besoin, redémarrage en 2 à 5 min."
                )
                image_max_size = gr.Slider(
                    256, 2048, value=VLM_IMAGE_MAX_SIZE, step=64,
                    label="Taille max de l'image (px, plus grand côté)",
                    info="Redimensionnement avant envoi au VLM. Plus petit = envoi/inférence plus rapides.",
                )
                extract_btn = gr.Button("Extraire les métadonnées", variant="primary")
                vlm_status = gr.HTML(status_card("Extraction VLM", "idle", "En attente."))
        extracted_json = gr.Code(language="json", label="JSON extrait", lines=20)
        with gr.Accordion("Réponse VLM brute (JSON complet)", open=False):
            vlm_raw_json = gr.Code(language="json", label="Réponse VLM brute", lines=20)
        gr.Markdown(
            "➡ **La validation de l'extraction se fait dans l'onglet « 2. Métadonnées "
            "corrigées »** : vérifiez-y les champs (corrigez-les si besoin), puis "
            "enregistrez le verdict qui alimente les datasets SFT/DPO."
        )

    with gr.Tab("2. Métadonnées corrigées"):
        gr.Markdown(
            "Cet onglet établit la **vérité terrain** (gold) qui alimente les futurs datasets de fine-tuning "
            "SFT/DPO et les modules suivants (Sudoc, IdRef, Dewey). Deux étapes :\n"
            "1. **Relisez les champs** du formulaire, pré-remplis par l'extraction de "
            "l'onglet 1 + corrigez-les si besoin, **à la main** ou en générant des données synthétiques via une "
            "**proposition par LLM** (bloc optionnel ci-dessous);\n"
            "2. **enregistrez la validation** en bas d'onglet : extraction **correcte** "
            "ou **corrigée**."
        )
        with gr.Accordion("Optionnel — Pré-remplir le formulaire par LLM (données synthétiques)", open=False):
            gr.Markdown(
                "Un LLM généraliste plus puissant (OpenAI, Hugging Face ou Albert) "
                "ré-extrait les métadonnées depuis l'image de l'onglet 1 et **pré-remplit "
                "le formulaire ci-dessous**. On parle de **données synthétiques** : une "
                "proposition générée par un modèle et qui ne devient vérité terrain "
                "qu'après votre relecture."
            )
            with gr.Row():
                correction_provider = gr.Radio(
                    [
                        ("OpenAI (gpt-4o)", "openai"),
                        ("Hugging Face", "huggingface"),
                        ("Albert API (Etalab)", "albert"),
                    ],
                    value="openai",
                    label="Fournisseur de correction",
                    scale=1,
                )
                with gr.Column(scale=1):
                    with gr.Group(visible=True) as openai_group:
                        openai_endpoint = gr.Textbox(value=DEFAULT_OPENAI_URL, label="Endpoint OpenAI")
                        openai_model = gr.Textbox(value=DEFAULT_OPENAI_MODEL, label="Modèle OpenAI")
                    with gr.Group(visible=False) as hf_group:
                        hf_endpoint = gr.Textbox(value=DEFAULT_HF_URL, label="Endpoint Hugging Face")
                        hf_model = gr.Dropdown(
                            choices=HF_MODEL_CHOICES,
                            value=DEFAULT_HF_MODEL,
                            label="Modèle Hugging Face",
                        )
                    with gr.Group(visible=False) as albert_group:
                        albert_endpoint = gr.Textbox(value=DEFAULT_ALBERT_URL, label="Endpoint Albert API")
                        albert_model = gr.Textbox(value=DEFAULT_ALBERT_MODEL, label="Modèle Albert API")
            correction_btn = gr.Button("Générer une correction par LLM", variant="secondary")
            correction_status = gr.HTML(status_card("Correction LLM", "idle", "En attente."))
        with gr.Row():
            title = gr.Textbox(label="Titre")
            subtitle = gr.Textbox(label="Sous-titre")
        with gr.Row():
            author = gr.Textbox(label="Auteur")
            degree_type = gr.Textbox(label="Type de diplôme")
        with gr.Row():
            discipline = gr.Textbox(label="Discipline")
            volume = gr.Textbox(label="Volume (n° de tome en chiffres arabes, vide si non mentionné)")
            granting_institution = gr.Textbox(label="Établissement de soutenance")
        with gr.Row():
            co_tutelle_institutions = gr.Textbox(label="Cotutelles (tableau JSON)")
            doctoral_school = gr.Textbox(label="École doctorale")
        with gr.Row():
            defense_year = gr.Textbox(label="Année de soutenance")
            language = gr.Textbox(label="Langue ISO 639-3")
            confidence = gr.Textbox(label="Confiance VLM")
        with gr.Row():
            advisor = gr.Textbox(label="Directeur(s) (tableau JSON)")
            jury_president = gr.Textbox(label="Président du jury")
        with gr.Row():
            reviewers = gr.Textbox(label="Rapporteurs (tableau JSON)")
            committee_members = gr.Textbox(label="Membres du jury (tableau JSON)")
        with gr.Group():
            gr.Markdown(
                "### Validation de l'extraction\n"
                "- **Extraction correcte** : le VLM a bien extrait, aucune correction "
                "nécessaire → dataset **SFT**, pas de paire DPO.\n"
                "- **Extraction corrigée** : le VLM s'est trompé, vous avez corrigé les "
                "champs (à la main ou via la proposition LLM relue) → dataset **SFT** "
                "(vérité terrain = champs corrigés) **+ paire DPO** (rejected = "
                "extraction brute de l'onglet 1)."
            )
            with gr.Row():
                vlm_verdict = gr.Radio(
                    [
                        ("Extraction correcte → SFT", "ok"),
                        ("Extraction corrigée → SFT + DPO", "corrected"),
                    ],
                    value="ok",
                    label="Verdict sur l'extraction",
                    scale=2,
                )
                vlm_remark = gr.Textbox(label="Remarque (optionnelle)", scale=3)
            vlm_save_btn = gr.Button("Enregistrer la validation", variant="primary")
            vlm_note_status = gr.HTML(status_card("Validation", "idle", "En attente."))
        corrected_json = gr.Code(language="json", label="JSON corrigé utilisé par les modules", lines=18)

    # L'ordre DOIT suivre config.METADATA_FIELDS (zip dans corrected_from_fields).
    metadata_inputs = [
        title,
        subtitle,
        author,
        degree_type,
        discipline,
        volume,
        granting_institution,
        co_tutelle_institutions,
        doctoral_school,
        defense_year,
        advisor,
        jury_president,
        reviewers,
        committee_members,
        language,
        confidence,
    ]

    with gr.Tab("3. Vérification Sudoc") as sudoc_tab:
        sudoc_api_url = gr.Textbox(value=DEFAULT_SUDOC_URL, label="API Sudoc checker")
        sudoc_btn = gr.Button("Lancer la vérification Sudoc", variant="primary")
        sudoc_html = gr.HTML()
        sudoc_candidates = gr.Dataframe(
            headers=["PPN", "Score", "Support", "Compte doublon imprimé", "Titre", "Auteur", "Année", "NNT", "URL"],
            datatype=["str", "str", "str", "bool", "str", "str", "str", "str", "str"],
            label="Candidats Sudoc",
            interactive=False,
            wrap=True,
        )
        sudoc_verdict, sudoc_remark, sudoc_note_btn, sudoc_note_status = notation_widget("Sudoc")
        with gr.Accordion("Réponse Sudoc brute (JSON)", open=False):
            sudoc_raw_json = gr.Code(language="json", label="Réponse Sudoc brute", lines=22)

    with gr.Tab("4. Alignement IdRef") as idref_tab:
        with gr.Row():
            idref_api_url = gr.Textbox(value=DEFAULT_IDREF_URL, label="API IdRef Qualinka")
            idref_api_key = gr.Textbox(value=DEFAULT_IDREF_API_KEY, label="API key IdRef", type="password")
        with gr.Row():
            use_embeddings = gr.Checkbox(value=True, label=f"Utiliser le mode embedding ({EMBEDDING_MODEL})")
        with gr.Accordion("Pondération du score de désambiguïsation", open=False):
            gr.Markdown(
                "Poids relatifs des indices combinés par le service idref-linker pour scorer chaque candidat. "
                "Idéalement leur somme vaut 1."
            )
            with gr.Row():
                weight_name = gr.Slider(
                    0.0, 1.0, value=DEFAULT_WEIGHT_NAME, step=0.05, label="Nom (weight_name)"
                )
                weight_attrra_source = gr.Slider(
                    0.0, 1.0, value=DEFAULT_WEIGHT_ATTRRA_SOURCE, step=0.05,
                    label="Sources attrRA (weight_attrra_source)",
                )
                weight_attrra_note = gr.Slider(
                    0.0, 1.0, value=DEFAULT_WEIGHT_ATTRRA_NOTE, step=0.05,
                    label="Notes attrRA (weight_attrra_note)",
                )
            with gr.Row():
                weight_references = gr.Slider(
                    0.0, 1.0, value=DEFAULT_WEIGHT_REFERENCES, step=0.05,
                    label="Références (weight_references)",
                )
                weight_institution_year = gr.Slider(
                    0.0, 1.0, value=DEFAULT_WEIGHT_INSTITUTION_YEAR, step=0.05,
                    label="Institution / année (weight_institution_year)",
                )
        with gr.Accordion("Paramètres avancés", open=False):
            gr.Markdown(
                "Paramètres de génération des candidats et seuils de décision du service "
                "idref-linker : nombre de candidats interrogés, volume de références "
                "récupérées par rôle, top-k des références moyennées, puis seuil "
                "d'acceptation (`accepted` vs `low_confidence`) et marge minimale entre "
                "les deux meilleurs scores (`ambiguous`)."
            )
            with gr.Row():
                idref_max_candidates = gr.Slider(
                    1, 100, value=DEFAULT_IDREF_MAX_CANDIDATES, step=1,
                    label="Max candidats (max_candidates)",
                )
                idref_max_docs_per_role = gr.Slider(
                    0, 200, value=DEFAULT_IDREF_MAX_DOCS_PER_ROLE, step=1,
                    label="Max références par rôle (max_docs_per_role)",
                )
                idref_reference_top_k = gr.Slider(
                    1, 20, value=DEFAULT_IDREF_REFERENCE_TOP_K, step=1,
                    label="Top-k références (reference_top_k)",
                )
            with gr.Row():
                idref_accept_threshold = gr.Slider(
                    0.0, 1.0, value=DEFAULT_IDREF_ACCEPT_THRESHOLD, step=0.01,
                    label="Seuil d'acceptation (accept_threshold)",
                )
                idref_margin_threshold = gr.Slider(
                    0.0, 1.0, value=DEFAULT_IDREF_MARGIN_THRESHOLD, step=0.01,
                    label="Marge d'ambiguïté (margin_threshold)",
                )
        gr.Markdown(
            "Le tableau liste les **personnes détectées** dans les métadonnées corrigées "
            "(onglet 2), avec le statut « à aligner ». Cliquez **« Aligner toutes les "
            "personnes »** pour le compléter avec les PPN IdRef proposés.\n\n"
            "**Validation manuelle** : après alignement, chaque ligne offre un champ PPN "
            "(candidats proposés à la saisie, PPN libre accepté) et un bouton « Valider » — "
            "utile quand la décision du service n'est pas « accepted » (low_confidence, "
            "ambiguous…). Les panneaux par personne ci-dessous détaillent **chaque candidat** "
            "(dépliez pour comparer) avec un bouton « Retenir ce PPN ». Le PPN validé est "
            "transmis au brouillon UNIMARC (onglet 6) comme alignement fort."
        )
        idref_btn = gr.Button("Aligner toutes les personnes", variant="primary")
        gr.Markdown("#### Personnes détectées / résumé des alignements")
        idref_table = gr.HTML(render_idref_table())
        idref_ppn_status = gr.HTML(status_card("Validation PPN", "idle", "Lancez d'abord un alignement."))
        # Pont JS de la validation manuelle : les boutons « Valider » (tableau) et
        # « Retenir ce PPN » (panneaux candidats) stashent {name, ppn} dans
        # window.__idrefPendingPick et cliquent idref_hidden_btn (voir IDREF_HEAD).
        # Même mécanique que le pont corpus : l'event-js du trigger relit la globale,
        # le placeholder n'est qu'un slot d'input ; les deux restent MONTÉS (cachés
        # via CSS, pas visible=False).
        idref_hidden_pick = gr.Textbox(elem_id="idref_hidden_pick", elem_classes=["corpus-bridge"])
        idref_hidden_btn = gr.Button("valider", elem_id="idref_hidden_btn", elem_classes=["corpus-bridge"])
        idref_html = gr.HTML()
        idref_verdict, idref_remark, idref_note_btn, idref_note_status = notation_widget("IdRef")
        with gr.Accordion("Réponses IdRef brutes (JSON)", open=False):
            idref_raw_json = gr.Code(language="json", label="Réponses IdRef brutes", lines=24)

    with gr.Tab("5. Classification Dewey") as dewey_tab:
        gr.Markdown(
            "Le texte classé est la concaténation `titre + sous-titre + discipline` des "
            "métadonnées corrigées. Les classes sont triées par score décroissant ; la "
            "première est présélectionnée. Validez-la ou choisissez-en une autre.\n\n"
            "**Méthode** : `local` (bi-encodeur local) ou `albert` (récupération bge-m3 + "
            "rerank bge-reranker-v2-m3 via l'API Albert). Les scores `albert` sont des scores "
            "de pertinence du reranker, non comparables aux scores de similarité `local`."
        )
        with gr.Row():
            dewey_api_url = gr.Textbox(value=DEFAULT_DEWEY_URL, label="API classification Dewey")
            dewey_api_key = gr.Textbox(value=DEFAULT_DEWEY_API_KEY, label="API key classification", type="password")
        with gr.Row():
            dewey_method = gr.Radio(
                choices=[("Local (bi-encodeur)", "local"), ("Albert (rerank)", "albert")],
                value="albert",
                label="Méthode de classification",
            )
            dewey_top_k = gr.Slider(1, 15, value=5, step=1, label="Nombre de classes (top_k)")
            dewey_threshold = gr.Slider(-1.0, 1.0, value=0.0, step=0.05, label="Seuil de similarité")
        dewey_btn = gr.Button("Classer (Dewey)", variant="primary")
        dewey_status = gr.HTML(status_card("Classification Dewey", "idle", "En attente."))
        dewey_choice = gr.Radio(choices=[], label="Classe Dewey retenue")
        dewey_select_btn = gr.Button("Valider la classe sélectionnée")
        dewey_html = gr.HTML()
        dewey_verdict, dewey_remark, dewey_note_btn, dewey_note_status = notation_widget("Dewey")
        with gr.Accordion("Réponse Dewey brute (JSON)", open=False):
            dewey_raw_json = gr.Code(language="json", label="Réponse Dewey brute", lines=20)

    with gr.Tab("6. Brouillon Unimarc") as draft_tab:
        draft_btn = gr.Button("Générer le brouillon consolidé", variant="primary")
        draft_html = gr.HTML()
        with gr.Row():
            with gr.Accordion("Brouillon JSON", open=False):
                draft_json = gr.Code(language="json", label="Brouillon JSON", lines=24)
            with gr.Accordion("État complet du pipeline (JSON)", open=False):
                pipeline_json = gr.Code(language="json", label="État complet du pipeline", lines=24)
        draft_verdict, draft_remark, draft_note_btn, draft_note_status = notation_widget("Brouillon")

    with gr.Tab("7. Spécifications Unimarc") as spec_tab:
        gr.Markdown(
            "### Spécifications UNIMARC collaboratives\n"
            "Version « vivante » du tableau du wiki : chaque zone/sous-zone est décrite par une "
            "signification, une priorité, un mode de production, un mapping vers les "
            "champs du pipeline et un statut. Sélectionnez une zone pour la modifier puis enregistrez une révision."
        )
        spec_counters = gr.HTML(spec_counters_html())
        spec_table = gr.HTML(render_spec_table())
        with gr.Group():
            gr.Markdown("#### Réviser une zone")
            with gr.Row():
                spec_field = gr.Dropdown(
                    choices=spec_field_choices(),
                    value=None,
                    label="Zone / sous-zone",
                    allow_custom_value=True,
                    scale=3,
                )
                spec_refresh_btn = gr.Button("Rafraîchir", scale=1)
            spec_field_html = gr.HTML(render_spec_field(None))
            with gr.Row():
                spec_status_choice = gr.Radio(SPEC_STATUS_CHOICES, value=None, label="Statut")
                spec_priority = gr.Dropdown(choices=[""] + SPEC_PRIORITY_CHOICES, value="", label="Priorité")
                spec_mode = gr.Dropdown(choices=[""] + SPEC_PRODUCTION_MODES, value="", label="Mode de production")
            spec_mapping = gr.Textbox(label="Mapping VLM/pipeline")
            spec_remark = gr.Textbox(label="Remarque / proposition", lines=5)
            spec_save_btn = gr.Button("Enregistrer la révision", variant="primary")
            spec_note_status = gr.HTML(status_card("Spécification UNIMARC", "idle", "En attente."))
        with gr.Group():
            gr.Markdown(
                "#### Exporter la spécification\n"
                "Les exports alimentent les spécifications finales : **Markdown** "
                "(recopie wiki), **CSV** (état courant à plat), **JSON** (avec historique)."
            )
            with gr.Row():
                spec_export_md_btn = gr.Button("Exporter Markdown (wiki)")
                spec_export_csv_btn = gr.Button("Exporter CSV")
                spec_export_json_btn = gr.Button("Exporter JSON (avec historique)")
            # Masqué tant qu'aucun export n'a produit de fichier : vide, gr.File
            # s'affiche comme une zone de dépôt (drag-and-drop) trompeuse.
            spec_export_file = gr.File(label="Fichier exporté", visible=False, interactive=False)
            spec_export_status = gr.HTML(status_card("Export spécification", "idle", "En attente."))

    with gr.Tab("8. Export Hugging Face") as export_tab:
        gr.Markdown(
            "Construit un dataset d'entraînement à partir des extractions validées "
            "**OK** (onglet 1). Un dépôt unique reçoit plusieurs configs : "
            "`sft_<format>` et `dpo_<format>` pour chaque variante de prompt, plus "
            "`raw` (journal d'annotations complet). Les images MinIO sont embarquées "
            "en octets (colonne `image`) et l'URL est conservée comme provenance.\n\n"
            "Nécessite la variable d'environnement `HF_TOKEN` avec droit d'écriture."
        )
        with gr.Row():
            hf_repo_id = gr.Textbox(value=DEFAULT_HF_DATASET_REPO, label="Dépôt dataset Hugging Face", scale=3)
            hf_formats = gr.CheckboxGroup(
                choices=[("classic (build_eval_prompt)", "classic"), ("lift (build_lift_prompt)", "lift"), ("nuextract", "nuextract")],
                value=list(EXPORT_FORMATS),
                label="Formats à exporter",
                scale=3,
            )
        with gr.Row():
            hf_include_raw = gr.Checkbox(value=True, label="Inclure la config brute (raw)")
            hf_private = gr.Checkbox(value=True, label="Dépôt privé")
            hf_embed_images = gr.Checkbox(value=True, label="Embarquer les images (octets)")
            hf_img_size = gr.Slider(256, 2048, value=EXPORT_IMAGE_MAX_SIZE, step=64, label="Taille max image (px)")
        with gr.Row():
            hf_preview_btn = gr.Button("Prévisualiser")
            hf_push_btn = gr.Button("Pousser vers le Hub", variant="primary")
        hf_push_status = gr.HTML(status_card("Export Hugging Face", "idle", "En attente."))
        hf_counts = gr.HTML()
        hf_sample = gr.Code(language="json", label="Exemple de ligne SFT (hors image)", lines=20)

    def toggle_provider_fields(provider: str, doc_type: str, current_prompt: str):
        p = str(provider or "qwen35").strip().lower()
        is_lift = p == "lift"
        # Swap the prompt template only when crossing the lift/non-lift boundary,
        # so manual edits within the same template family are preserved.
        prompt_is_lift = str(current_prompt or "").lstrip().startswith("Extract structured data")
        if is_lift and not prompt_is_lift:
            prompt_update = gr.update(value=build_lift_prompt(doc_type))
        elif not is_lift and prompt_is_lift:
            prompt_update = gr.update(value=build_eval_prompt(doc_type))
        else:
            prompt_update = gr.update()
        return (
            gr.update(visible=p == "vlm"),
            gr.update(visible=is_lift),
            gr.update(visible=p == "qwen35"),
            prompt_update,
        )

    vlm_provider.change(
        toggle_provider_fields,
        inputs=[vlm_provider, doc_type, prompt],
        outputs=[vlm_group, lift_group, qwen35_group, prompt],
    ).then(
        # Après le basculement visuel : rafraîchit le statut de l'endpoint dédié
        # (appel réseau) uniquement quand lift est sélectionné.
        refresh_lift_status_on_provider,
        inputs=[vlm_provider],
        outputs=[lift_ep_status],
    )

    lift_ep_check_btn.click(check_lift_endpoint, inputs=None, outputs=[lift_ep_status])
    lift_ep_wake_btn.click(wake_lift_endpoint, inputs=None, outputs=[lift_ep_status])

    def toggle_correction_provider(provider: str):
        p = str(provider or "openai").strip().lower()
        return (
            gr.update(visible=p == "openai"),
            gr.update(visible=p in {"huggingface", "hf"}),
            gr.update(visible=p == "albert"),
        )

    correction_provider.change(
        toggle_correction_provider,
        inputs=[correction_provider],
        outputs=[openai_group, hf_group, albert_group],
    )

    def rebuild_prompt(doc_type: str, provider: str):
        p = str(provider or "qwen35").strip().lower()
        return build_lift_prompt(doc_type) if p == "lift" else build_eval_prompt(doc_type)

    doc_type.change(rebuild_prompt, inputs=[doc_type, vlm_provider], outputs=[prompt])

    extract_btn.click(
        call_vlm,
        inputs=[
            state,
            annotator,
            doc_type,
            image_url,
            prompt,
            vlm_provider,
            vlm_endpoint,
            vlm_model,
            openai_endpoint,
            openai_model,
            hf_endpoint,
            hf_model,
            albert_endpoint,
            albert_model,
            lift_endpoint,
            lift_model,
            qwen35_endpoint,
            qwen35_model,
            image_max_size,
        ],
        outputs=[state, extracted_json, vlm_raw_json, vlm_status, *metadata_inputs],
    ).then(
        update_corrected_metadata,
        inputs=[state, *metadata_inputs],
        outputs=[state, corrected_json, idref_table, summary],
    )

    correction_btn.click(
        call_correction_llm,
        inputs=[
            state,
            correction_provider,
            openai_endpoint,
            openai_model,
            hf_endpoint,
            hf_model,
            albert_endpoint,
            albert_model,
            image_max_size,
        ],
        outputs=[state, correction_status, *metadata_inputs],
    ).then(
        update_corrected_metadata,
        inputs=[state, *metadata_inputs],
        outputs=[state, corrected_json, idref_table, summary],
    )

    vlm_save_btn.click(
        validate_extraction,
        inputs=[state, annotator, vlm_verdict, vlm_remark, *metadata_inputs],
        outputs=[state, corrected_json, vlm_note_status, idref_table, summary],
    )

    for note_btn, note_verdict, note_remark, note_status, note_step in (
        (sudoc_note_btn, sudoc_verdict, sudoc_remark, sudoc_note_status, "sudoc"),
        (idref_note_btn, idref_verdict, idref_remark, idref_note_status, "idref"),
        (dewey_note_btn, dewey_verdict, dewey_remark, dewey_note_status, "dewey"),
        (draft_note_btn, draft_verdict, draft_remark, draft_note_status, "draft"),
    ):
        note_btn.click(
            partial(save_step_note, step=note_step),
            inputs=[state, annotator, note_verdict, note_remark],
            outputs=[state, note_btn, note_status, summary],
        )

    sudoc_btn.click(
        call_sudoc,
        inputs=[state, doc_type, sudoc_api_url],
        outputs=[state, sudoc_html, sudoc_raw_json, sudoc_candidates, summary],
    ).success(
        # Le drapeau state["notes"]["sudoc"]="pending" est posé par call_sudoc ;
        # ici on ne fait que passer le widget de notation en alerte (sans état).
        partial(note_pending_updates, "sudoc"),
        inputs=None,
        outputs=[sudoc_note_btn, sudoc_note_status],
    )

    idref_btn.click(
        call_idref_for_all,
        inputs=[
            state,
            idref_api_url,
            idref_api_key,
            use_embeddings,
            weight_name,
            weight_attrra_source,
            weight_attrra_note,
            weight_references,
            weight_institution_year,
            idref_max_candidates,
            idref_max_docs_per_role,
            idref_reference_top_k,
            idref_accept_threshold,
            idref_margin_threshold,
        ],
        outputs=[state, idref_html, idref_raw_json, idref_table, summary],
    ).success(
        partial(note_pending_updates, "idref"),
        inputs=None,
        outputs=[idref_note_btn, idref_note_status],
    )

    # Pont JS : l'event-js remplace les valeurs d'entrée par [state inchangé,
    # window.__idrefPendingPick] — le JSON {name, ppn} stashé par le bouton cliqué.
    idref_hidden_btn.click(
        validate_idref_ppn_from_bridge,
        inputs=[state, idref_hidden_pick],
        outputs=[state, idref_ppn_status, idref_html, idref_table, summary],
        js="(s, x) => [s, window.__idrefPendingPick || '']",
    )

    dewey_btn.click(
        call_dewey,
        inputs=[state, dewey_api_url, dewey_api_key, dewey_top_k, dewey_threshold, dewey_method],
        outputs=[state, dewey_html, dewey_raw_json, dewey_choice, summary],
    ).success(
        partial(note_pending_updates, "dewey"),
        inputs=None,
        outputs=[dewey_note_btn, dewey_note_status],
    )

    dewey_select_btn.click(
        select_dewey_class,
        inputs=[state, dewey_choice],
        outputs=[state, dewey_status, summary],
    )

    dewey_choice.change(
        select_dewey_class,
        inputs=[state, dewey_choice],
        outputs=[state, dewey_status, summary],
    )

    spec_form = [spec_status_choice, spec_priority, spec_mode, spec_mapping, spec_remark]
    spec_outputs = [spec_counters, spec_table, spec_field, spec_field_html, *spec_form]

    draft_btn.click(
        make_record_draft,
        inputs=[state],
        outputs=[state, draft_html, draft_json, pipeline_json],
    ).success(
        partial(note_pending_updates, "draft"),
        inputs=None,
        outputs=[draft_note_btn, draft_note_status],
    ).then(
        pipeline_summary,
        inputs=[state],
        outputs=[summary],
    ).then(
        refresh_spec_view,
        inputs=[spec_field, state],
        outputs=spec_outputs,
    )

    spec_field.change(select_spec_field, inputs=[spec_field], outputs=[spec_field_html, *spec_form])
    spec_refresh_btn.click(refresh_spec_view, inputs=[spec_field, state], outputs=spec_outputs)

    spec_save_btn.click(
        save_spec_revision,
        inputs=[annotator, spec_field, spec_status_choice, spec_priority, spec_mode, spec_mapping, spec_remark],
        outputs=[spec_note_status, spec_counters, spec_table, spec_field_html],
    )

    for spec_btn, spec_fmt in (
        (spec_export_md_btn, "markdown"),
        (spec_export_csv_btn, "csv"),
        (spec_export_json_btn, "json"),
    ):
        spec_btn.click(
            partial(export_spec, spec_fmt),
            inputs=None,
            outputs=[spec_export_file, spec_export_status],
        )

    # Rappel non bloquant (gr.Warning) à l'ouverture d'un onglet : liste les avis
    # encore non enregistrés sur les étapes des onglets précédents. Les onglets
    # 7/8 et Corpus vérifient tout (avant de changer de document notamment).
    for nag_tab, upto in (
        (sudoc_tab, 3),
        (idref_tab, 4),
        (dewey_tab, 5),
        (draft_tab, 6),
        (spec_tab, 7),
        (export_tab, 7),
        (corpus_tab, 7),
    ):
        nag_tab.select(
            partial(warn_pending_notes, upto_tab=upto),
            inputs=[state],
            outputs=[],
        )

    corpus_outputs = [corpus_table_html, corpus_counters, corpus_url_state]
    corpus_refresh_btn.click(refresh_corpus, inputs=[corpus_filter], outputs=corpus_outputs)
    corpus_filter.change(refresh_corpus, inputs=[corpus_filter], outputs=corpus_outputs).then(
        lambda: [], inputs=None, outputs=[corpus_gallery]
    )
    demo.load(refresh_corpus, inputs=[corpus_filter], outputs=corpus_outputs)

    corpus_gallery_btn.click(build_corpus_gallery, inputs=[corpus_url_state], outputs=[corpus_gallery])

    # Charger un document = remise à zéro de tous les onglets + restauration de
    # l'avancement journalisé (corpus.load_doc_into_pipeline). L'ordre DOIT
    # suivre corpus.RESUME_OUTPUT_ORDER (assert ci-dessous).
    resume_outputs = [
        image_url, doc_type, url_preview, corpus_select_status,
        state, summary,
        extracted_json, vlm_raw_json, vlm_status,
        *metadata_inputs,
        correction_status, corrected_json,
        vlm_verdict, vlm_remark, vlm_note_status,
        sudoc_html, sudoc_raw_json, sudoc_candidates, sudoc_verdict, sudoc_remark, sudoc_note_btn, sudoc_note_status,
        idref_table, idref_html, idref_raw_json, idref_ppn_status, idref_verdict, idref_remark, idref_note_btn, idref_note_status,
        dewey_status, dewey_choice, dewey_html, dewey_raw_json, dewey_verdict, dewey_remark, dewey_note_btn, dewey_note_status,
        draft_html, draft_json, pipeline_json, draft_verdict, draft_remark, draft_note_btn, draft_note_status,
    ]
    assert len(resume_outputs) == len(RESUME_OUTPUT_ORDER), (
        f"resume_outputs ({len(resume_outputs)}) désynchronisé de "
        f"corpus.RESUME_OUTPUT_ORDER ({len(RESUME_OUTPUT_ORDER)})"
    )

    corpus_hidden_btn.click(
        load_picked_url,
        inputs=[corpus_hidden_url],
        outputs=resume_outputs,
        js="(x) => [window.__corpusPendingUrl || '']",
    )
    corpus_gallery.select(
        load_url_from_corpus,
        inputs=[corpus_url_state],
        outputs=resume_outputs,
    )

    image_url.change(render_image_preview, inputs=[image_url], outputs=[url_preview])

    hf_preview_btn.click(
        preview_export,
        inputs=[hf_formats, hf_include_raw],
        outputs=[hf_counts, hf_sample],
    )
    hf_push_btn.click(
        push_export_to_hub,
        inputs=[hf_repo_id, hf_formats, hf_include_raw, hf_private, hf_embed_images, hf_img_size],
        outputs=[hf_push_status],
    )

demo.launch(css=CSS(), head=CORPUS_HEAD + IDREF_HEAD)
