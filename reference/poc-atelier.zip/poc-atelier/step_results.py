"""Journal des résultats d'étapes (append-only JSONL, partagé entre sessions).

Complément du journal d'annotations : conserve la DERNIÈRE réponse de chaque
étape aval (Sudoc, IdRef — PPN validés manuellement compris —, Dewey, brouillon
Unimarc) par page de titre, pour restaurer les onglets 3-6 au chargement d'un
document (corpus.load_doc_into_pipeline) sans rappeler les API. Délibérément
séparé d'annotations.jsonl : celui-ci est la source des datasets d'entraînement
et de l'export HF (config `raw`), ce journal-ci n'est qu'un cache de résultats,
exclu de l'export.

Schéma d'un événement (une ligne JSON dans STEP_RESULTS_PATH) :
  ts         horodatage ISO-8601 UTC (posé par record_step_result)
  image_url  URL MinIO de la page de titre — clé de pliage
  step       "sudoc" | "idref" | "dewey" | "draft"
  payload    le résultat à restaurer, tel que stocké dans le gr.State :
             sudoc  {route, request, response}
             idref  {persons, settings}   (persons inclut manual_ppn/manual_url)
             dewey  {request, response, classes, selected}
             draft  {draft}
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from config import STEP_RESULTS_PATH, _STEP_RESULTS_LOCK


def record_step_result(image_url: str | None, step: str, payload: dict[str, Any]) -> None:
    """Journalise durablement le dernier résultat d'une étape pour une page.
    Sans URL d'image (page non suivie), n'écrit rien — même règle que les
    événements `extract` du journal d'annotations."""
    url = (image_url or "").strip()
    if not url:
        return
    event = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "image_url": url,
        "step": step,
        "payload": payload,
    }
    line = json.dumps(event, ensure_ascii=False)
    with _STEP_RESULTS_LOCK:
        with STEP_RESULTS_PATH.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")


def read_step_results() -> list[dict[str, Any]]:
    """Lit le journal complet, tolérant fichier absent et ligne finale tronquée."""
    if not STEP_RESULTS_PATH.exists():
        return []
    with _STEP_RESULTS_LOCK:
        raw = STEP_RESULTS_PATH.read_text(encoding="utf-8")
    events: list[dict[str, Any]] = []
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return events


def fold_step_results(events: list[dict[str, Any]] | None = None) -> dict[str, dict[str, Any]]:
    """Plie le journal en état courant : {image_url: {step: {payload, ts}}},
    le dernier événement gagnant pour une (page, étape) donnée."""
    events = events if events is not None else read_step_results()
    records: dict[str, dict[str, Any]] = {}
    for ev in events:
        url = ev.get("image_url")
        step = ev.get("step")
        if not url or not step:
            continue
        records.setdefault(url, {})[step] = {"payload": ev.get("payload"), "ts": ev.get("ts")}
    return records
