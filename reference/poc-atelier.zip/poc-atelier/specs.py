"""Spécifications collaboratives par champ (onglet 7). Mécanisme générique et
réutilisable hors catalogage de thèses : un fichier seed (SPEC_SEED_PATH) définit
les champs de la spécification — ici les zones/sous-zones UNIMARC issues du wiki —
et un journal append-only JSONL (SPEC_EVENTS_PATH) porte les révisions des
annotateurs, pliées en « spec vivante » à la lecture (même patron que le journal
d'annotations). Les exports Markdown/CSV/JSON alimentent les spécifications
finales (recopie wiki incluse). Pour un autre projet (MARC21, Dublin Core…),
pointer SPEC_SEED_PATH vers un autre seed suffit."""

from __future__ import annotations

import csv
import html
import json
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import gradio as gr

from config import SPEC_EVENTS_PATH, SPEC_SEED_PATH, _SPEC_EVENTS_LOCK
from render import status_card

# Colonnes révisables d'un champ de spec. Un événement ne porte que les colonnes
# effectivement modifiées ; le pli applique « la dernière valeur non vide gagne ».
SPEC_COLUMNS = ["label", "priority", "production_mode", "mapping", "remark", "links", "status"]

SPEC_STATUS_LABELS = {
    "seed": "Seed (non discuté)",
    "a_discuter": "À discuter",
    "valide": "Validé",
    "rejete": "Rejeté",
}
SPEC_STATUS_CHOICES = [(label, key) for key, label in SPEC_STATUS_LABELS.items() if key != "seed"]

SPEC_PRODUCTION_MODES = [
    "Valeur fixe",
    "Valeur générée par IA",
    "Valeur dérivée de règles métiers",
    "Saisie manuelle",
    "IA + alignement (IdRef/Dewey)",
    "Attribué par le Sudoc",
]

SPEC_PRIORITY_CHOICES = ["1", "2", "3", "4"]


# --- Event schema (one JSON object per line in SPEC_EVENTS_PATH) ---
#   ts          ISO-8601 UTC timestamp (stamped at append time)
#   annotator   free-text reviewer name
#   field_id    spec field key everything folds onto (e.g. "029 $a")
#   action      "spec" (single action for now; keeps the log extensible)
#   status      "a_discuter" | "valide" | "rejete"      (optional)
#   priority, production_mode, mapping, remark, links   (optional, only if revised)


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def read_spec_seed() -> list[dict[str, Any]]:
    """Load the seed spec (field definitions + initial wiki content). Missing or
    invalid file degrades to an empty seed: the log alone can still define fields."""
    if not SPEC_SEED_PATH.exists():
        return []
    try:
        data = json.loads(SPEC_SEED_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []
    return [entry for entry in data if isinstance(entry, dict) and entry.get("field_id")] if isinstance(data, list) else []


def append_spec_event(event: dict[str, Any]) -> dict[str, Any]:
    """Stamp and durably append one spec revision (same locking pattern as the
    annotation store)."""
    event = {"ts": utc_now_iso(), "action": "spec", **event}
    line = json.dumps(event, ensure_ascii=False)
    with _SPEC_EVENTS_LOCK:
        with SPEC_EVENTS_PATH.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    return event


def read_spec_events() -> list[dict[str, Any]]:
    if not SPEC_EVENTS_PATH.exists():
        return []
    events: list[dict[str, Any]] = []
    with _SPEC_EVENTS_LOCK:
        raw = SPEC_EVENTS_PATH.read_text(encoding="utf-8")
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return events


def _blank_spec_record(field_id: str) -> dict[str, Any]:
    return {
        "field_id": field_id,
        "label": "",
        "priority": "",
        "production_mode": "",
        "mapping": "",
        "remark": "",
        "links": "",
        "status": "seed",
        "history": [],
        "annotators": [],
        "last_ts": None,
    }


def fold_spec(events: list[dict[str, Any]] | None = None) -> dict[str, dict[str, Any]]:
    """Fold seed + revision log into the current living spec, keyed by field_id.
    For each revisable column the latest non-empty value wins; the full revision
    history is kept per field for the discussion trail."""
    records: dict[str, dict[str, Any]] = {}
    for entry in read_spec_seed():
        rec = _blank_spec_record(str(entry["field_id"]))
        for col in SPEC_COLUMNS:
            if entry.get(col) not in (None, ""):
                rec[col] = str(entry[col])
        rec["status"] = str(entry.get("status") or "seed")
        records[rec["field_id"]] = rec
    events = events if events is not None else read_spec_events()
    for ev in events:
        field_id = str(ev.get("field_id") or "").strip()
        if not field_id or ev.get("action") != "spec":
            continue
        rec = records.setdefault(field_id, _blank_spec_record(field_id))
        for col in SPEC_COLUMNS:
            if ev.get(col) not in (None, ""):
                rec[col] = str(ev[col])
        annotator = (ev.get("annotator") or "").strip()
        if annotator and annotator not in rec["annotators"]:
            rec["annotators"].append(annotator)
        rec["last_ts"] = ev.get("ts") or rec["last_ts"]
        rec["history"].append({
            "ts": ev.get("ts"),
            "annotator": annotator,
            **{col: ev.get(col) for col in SPEC_COLUMNS if ev.get(col) not in (None, "")},
        })
    return records


def zones_from_unimarc_text(text: str | None) -> list[str]:
    """Extract the zone codes (e.g. "200", "029") from a pseudo-UNIMARC preview so a
    reviewer can annotate a field in the context of a concrete generated example."""
    zones: list[str] = []
    for line in str(text or "").splitlines():
        tag = line[:3].strip()
        if tag.isdigit() and tag not in zones:
            zones.append(tag)
    return zones


def spec_field_choices(records: dict[str, dict[str, Any]] | None = None, extra_zones: list[str] | None = None) -> list[str]:
    """Dropdown choices: every known spec field, plus zones present in the current
    draft that no seed/log entry covers yet (so they can be specified on the spot)."""
    records = records if records is not None else fold_spec()
    choices = sorted(records.keys())
    for zone in extra_zones or []:
        if not any(fid == zone or fid.startswith(f"{zone} ") for fid in choices):
            choices.append(zone)
    return sorted(choices)


def spec_counters_html(records: dict[str, dict[str, Any]] | None = None) -> str:
    records = records if records is not None else fold_spec()
    counts = {key: 0 for key in SPEC_STATUS_LABELS}
    for rec in records.values():
        counts[rec.get("status") if rec.get("status") in counts else "seed"] += 1
    revisions = sum(len(rec.get("history") or []) for rec in records.values())
    tiles = [
        ("Champs", len(records)),
        ("Validés", counts["valide"]),
        ("À discuter", counts["a_discuter"]),
        ("Rejetés", counts["rejete"]),
        ("Non discutés", counts["seed"]),
        ("Révisions", revisions),
    ]
    cells = "".join(f"<div><strong>{html.escape(label)}</strong><br>{value}</div>" for label, value in tiles)
    return f"<div class='summary-grid'>{cells}</div>"


def render_spec_table(records: dict[str, dict[str, Any]] | None = None) -> str:
    """Living spec as a static HTML table (same choice as the corpus dashboard:
    gr.Dataframe freezes on large read-only tables)."""
    records = records if records is not None else fold_spec()
    if not records:
        return "<p class='muted'>Aucun champ de spécification (seed absent et journal vide).</p>"
    headers = ["Zone", "Signification", "Priorité", "Statut", "Mode de production", "Mapping VLM/pipeline", "Remarque", "Révisions", "Annotateurs"]
    head = "".join(f"<th>{html.escape(h)}</th>" for h in headers)
    body_rows = []
    for field_id in sorted(records):
        rec = records[field_id]
        status = rec.get("status") or "seed"
        body_rows.append(
            "<tr>"
            f"<td><code>{html.escape(field_id)}</code></td>"
            f"<td>{html.escape(rec.get('label') or '')}</td>"
            f"<td>{html.escape(rec.get('priority') or '')}</td>"
            f"<td>{html.escape(SPEC_STATUS_LABELS.get(status, status))}</td>"
            f"<td>{html.escape(rec.get('production_mode') or '')}</td>"
            f"<td>{html.escape(rec.get('mapping') or '')}</td>"
            f"<td>{html.escape(rec.get('remark') or '')}</td>"
            f"<td>{len(rec.get('history') or [])}</td>"
            f"<td>{html.escape(' | '.join(rec.get('annotators') or []))}</td>"
            "</tr>"
        )
    return (
        "<div style='max-height:520px;overflow:auto'>"
        f"<table class='data-table'><thead><tr>{head}</tr></thead>"
        f"<tbody>{''.join(body_rows)}</tbody></table></div>"
    )


def render_spec_field(field_id: str | None, records: dict[str, dict[str, Any]] | None = None) -> str:
    """Current state + full revision history of one field."""
    field_id = (field_id or "").strip()
    if not field_id:
        return "<p class='muted'>Sélectionnez une zone pour voir sa spécification et son historique.</p>"
    records = records if records is not None else fold_spec()
    rec = records.get(field_id) or _blank_spec_record(field_id)
    status = rec.get("status") or "seed"
    links = (rec.get("links") or "").strip()
    links_html = f"<p><strong>Liens :</strong> <a href='{html.escape(links, quote=True)}' target='_blank'>{html.escape(links)}</a></p>" if links else ""
    history = rec.get("history") or []
    if history:
        items = []
        for h in reversed(history):
            changes = "; ".join(
                f"{col} → {h[col]}" for col in SPEC_COLUMNS if col in h
            )
            items.append(
                f"<li><strong>{html.escape(h.get('annotator') or 'anonyme')}</strong>"
                f" <span class='muted'>({html.escape(str(h.get('ts') or ''))})</span><br>{html.escape(changes)}</li>"
            )
        history_html = f"<h4>Historique des révisions ({len(history)})</h4><ul>{''.join(items)}</ul>"
    else:
        history_html = "<p class='muted'>Aucune révision : valeurs issues du seed.</p>"
    return f"""
    <section class="panel">
      <h3>Zone <code>{html.escape(field_id)}</code></h3>
      <p><strong>Signification :</strong> {html.escape(rec.get('label') or '—')}</p>
      <p><strong>Priorité :</strong> {html.escape(rec.get('priority') or '—')}
         · <strong>Statut :</strong> {html.escape(SPEC_STATUS_LABELS.get(status, status))}</p>
      <p><strong>Mode de production :</strong> {html.escape(rec.get('production_mode') or '—')}</p>
      <p><strong>Mapping VLM/pipeline :</strong> {html.escape(rec.get('mapping') or '—')}</p>
      <p><strong>Remarque :</strong> {html.escape(rec.get('remark') or '—')}</p>
      {links_html}
      {history_html}
    </section>
    """


def spec_form_values(field_id: str | None, records: dict[str, dict[str, Any]] | None = None) -> tuple[str | None, str, str, str, str]:
    """Valeurs courantes d'un champ pour préremplir le formulaire de révision :
    (statut, priorité, mode de production, mapping, remarque). Le statut « seed »
    n'est pas proposé au choix → None (aucune présélection) ; une valeur pliée hors
    vocabulaire retombe sur vide plutôt que de casser le composant."""
    records = records if records is not None else fold_spec()
    rec = records.get((field_id or "").strip()) or {}
    status = rec.get("status") or ""
    priority = rec.get("priority") or ""
    mode = rec.get("production_mode") or ""
    return (
        status if status in {key for _, key in SPEC_STATUS_CHOICES} else None,
        priority if priority in SPEC_PRIORITY_CHOICES else "",
        mode if mode in SPEC_PRODUCTION_MODES else "",
        rec.get("mapping") or "",
        rec.get("remark") or "",
    )


def select_spec_field(field_id: str | None) -> tuple[str, str | None, str, str, str, str]:
    """Sélection d'une zone dans le dropdown : rafraîchit le panneau (état +
    historique) et préremplit le formulaire de révision avec l'état courant."""
    records = fold_spec()
    return (render_spec_field(field_id, records), *spec_form_values(field_id, records))


def save_spec_revision(
    annotator: str,
    field_id: str,
    status: str | None,
    priority: str | None,
    production_mode: str | None,
    mapping: str,
    remark: str,
) -> tuple[str, str, str, str]:
    """Append one collaborative revision on a spec field. The form is pre-filled
    with the current folded state, so only the columns actually *changed* (non-empty
    and different from the current value) are recorded — the history stays a diff
    trail. Returns the status card + refreshed counters/table/field panel."""
    field_id = (field_id or "").strip()
    if not field_id:
        raise gr.Error("Sélectionnez la zone à annoter.")
    current = fold_spec().get(field_id) or _blank_spec_record(field_id)
    proposed = {
        "status": (status or "").strip(),
        "priority": str(priority or "").strip(),
        "production_mode": (production_mode or "").strip(),
        "mapping": (mapping or "").strip(),
        "remark": (remark or "").strip(),
    }
    changes = {col: val for col, val in proposed.items() if val and val != (current.get(col) or "")}
    if not changes:
        raise gr.Error(
            "Aucune modification détectée : changez au moins un élément "
            "(statut, priorité, mode, mapping ou remarque)."
        )
    append_spec_event({"annotator": (annotator or "").strip(), "field_id": field_id, **changes})
    records = fold_spec()
    return (
        status_card("Spécification UNIMARC", "ok", f"Révision enregistrée pour la zone {field_id}."),
        spec_counters_html(records),
        render_spec_table(records),
        render_spec_field(field_id, records),
    )


# --- Exports : alimentent les spécifications finales (recopie wiki, tableur, JSON). ---

SPEC_EXPORT_HEADERS = ["Zone", "Signification", "Priorité", "Statut", "Mode de production", "Mapping VLM/pipeline", "Remarque", "Liens utiles"]


def _spec_export_rows(records: dict[str, dict[str, Any]]) -> list[list[str]]:
    rows = []
    for field_id in sorted(records):
        rec = records[field_id]
        status = rec.get("status") or "seed"
        rows.append([
            field_id,
            rec.get("label") or "",
            rec.get("priority") or "",
            SPEC_STATUS_LABELS.get(status, status),
            rec.get("production_mode") or "",
            rec.get("mapping") or "",
            rec.get("remark") or "",
            rec.get("links") or "",
        ])
    return rows


def export_spec(fmt: str) -> tuple[Any, str]:
    """Write the living spec to a downloadable file. Markdown is wiki-paste-ready;
    JSON keeps the revision history; CSV is the flat current state. Returns a
    gr.update revealing the file component (hidden while no export exists)."""
    fmt = (fmt or "markdown").strip().lower()
    records = fold_spec()
    if not records:
        raise gr.Error("Aucune spécification à exporter.")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    out_dir = Path(tempfile.mkdtemp(prefix="unimarc_spec_"))
    if fmt == "json":
        path = out_dir / f"spec-{stamp}.json"
        path.write_text(json.dumps(list(records.values()), ensure_ascii=False, indent=2), encoding="utf-8")
    elif fmt == "csv":
        path = out_dir / f"spec-{stamp}.csv"
        with path.open("w", encoding="utf-8", newline="") as fh:
            writer = csv.writer(fh)
            writer.writerow(SPEC_EXPORT_HEADERS)
            writer.writerows(_spec_export_rows(records))
    else:
        path = out_dir / f"spec-{stamp}.md"
        lines = [
            "| " + " | ".join(SPEC_EXPORT_HEADERS) + " |",
            "| " + " | ".join("---" for _ in SPEC_EXPORT_HEADERS) + " |",
        ]
        for row in _spec_export_rows(records):
            lines.append("| " + " | ".join(cell.replace("|", "\\|").replace("\n", " ") for cell in row) + " |")
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return (
        gr.update(value=str(path), visible=True),
        status_card("Export spécification", "ok", f"Fichier {path.name} généré ({len(records)} champs)."),
    )
