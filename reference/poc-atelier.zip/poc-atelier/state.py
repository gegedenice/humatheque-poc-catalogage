"""État de session du pipeline (gr.State) : structure, journal d'événements et
petits utilitaires JSON. Contrat : chaque handler fait deepcopy, mute son
sous-dict et passe par add_event — jamais de mutation en place."""

from __future__ import annotations

import json
from copy import deepcopy
from typing import Any

import gradio as gr


def empty_state() -> dict[str, Any]:
    return {
        "input": {"doc_type": "these", "image_url": "", "image_filename": ""},
        "vlm": {"request": None, "raw_response": None, "extracted": None, "corrected": None, "error": None},
        "sudoc": {"request": None, "response": None, "error": None},
        "idref": {"persons": [], "settings": {}, "error": None},
        "dewey": {"request": None, "response": None, "classes": [], "selected": None, "error": None},
        "record_draft": None,
        # Suivi de notation par étape (vlm|sudoc|idref|dewey|draft) :
        # absent = étape non exécutée ; "pending" = résultat produit mais avis
        # non enregistré ; sinon le verdict enregistré ("ok"/"ko"/"corrected").
        "notes": {},
        "events": [],
    }


def add_event(state: dict[str, Any], step: str, status: str, message: str) -> dict[str, Any]:
    state = deepcopy(state or empty_state())
    state.setdefault("events", []).append({"step": step, "status": status, "message": message})
    return state


def as_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2)


def load_json_object(text: str, label: str = "JSON") -> dict[str, Any]:
    try:
        value = json.loads(text)
    except json.JSONDecodeError as exc:
        raise gr.Error(f"{label} invalide: {exc}") from exc
    if not isinstance(value, dict):
        raise gr.Error(f"{label} doit être un objet.")
    return value
