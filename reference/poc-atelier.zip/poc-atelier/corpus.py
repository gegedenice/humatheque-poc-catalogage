"""Tableau de bord Corpus / Dataset : croise la liste MinIO fixe avec le journal
d'annotations plié. Une ligne par page de titre : statut binaire (traité = une
validation VLM enregistrée dans l'onglet 2) + avis OK/KO de chaque étape aval.
Table HTML statique + pont JS pour les boutons « Charger » (voir CORPUS_HEAD).
Charger un document remet tous les onglets à zéro puis restaure l'avancement
déjà journalisé pour reprendre le traitement là où il s'était arrêté
(load_doc_into_pipeline) : extraction brute + métadonnées validées + avis
(annotations.jsonl) ET derniers résultats Sudoc/IdRef/Dewey/brouillon — PPN
validés manuellement compris — (step_results.jsonl), sans rappeler les API."""

from __future__ import annotations

import html
from typing import Any

import gradio as gr

from annotations import (
    STEP_NOTE_LABELS,
    STEP_TAB_NUMBERS,
    VALIDATED_VERDICTS,
    fold_log,
    note_button_update,
    parse_minio_url,
)
from config import METADATA_FIELDS, MINIO_URLS_PATH
from dataset_export import dpo_pair
from metadata import extract_people, metadata_to_outputs, normalize_metadata
from render import (
    pipeline_summary,
    render_dewey,
    render_idref,
    render_idref_table,
    render_image_preview,
    render_sudoc,
    status_card,
    sudoc_candidate_rows,
)
from services import dewey_radio_update
from state import add_event, as_json, empty_state
from step_results import fold_step_results
from unimarc import render_draft


# --------------------------------------------------------------------------
# Corpus / Dataset dashboard. Cross-references the fixed MinIO URL list with the
# folded annotation log so a reviewer can see, per title page, whether it has been
# processed (a validation recorded in tab 2), whether it feeds the DPO dataset,
# and the collaborative OK/KO verdict of every downstream step (tabs 3-6).
# --------------------------------------------------------------------------

CORPUS_STATUS_LABELS = {
    "traite": "Traité",
    "non_traite": "Non traité",
}


CORPUS_FILTER_CHOICES = [("Tous", "tous"), *[(label, key) for key, label in CORPUS_STATUS_LABELS.items()]]


DOC_TYPE_LABELS = {"these": "Thèse", "memoire": "Mémoire"}


CORPUS_HEADERS = ["URL", "Collection", "Type", "Statut", "Annotateur", "DPO", "Sudoc", "IdRef", "Dewey", "Brouillon Unimarc"]


# Étapes aval notées OK/KO (onglets 3-6), dans l'ordre des colonnes du tableau.
CORPUS_STEP_COLUMNS = ["sudoc", "idref", "dewey", "draft"]


STEP_VERDICT_LABELS = {"ok": "OK", "ko": "KO"}


CORPUS_GALLERY_CAP = 24


def parse_minio_urls_file() -> list[dict[str, str]]:
    """Parse minio_urls.txt into [{url}]. Each line is `<index> <url> [marker]`;
    the free-text wiki markers after the URL (FAIT, DEWEY, ...) are ignored — the
    computed status comes from the annotation log only."""
    if not MINIO_URLS_PATH.exists():
        return []
    entries: list[dict[str, str]] = []
    for line in MINIO_URLS_PATH.read_text(encoding="utf-8").splitlines():
        url = next((tok for tok in line.split() if tok.startswith("http")), None)
        if url:
            entries.append({"url": url})
    return entries


def _vlm_verdict(rec: dict[str, Any] | None) -> str | None:
    return (((rec or {}).get("steps") or {}).get("vlm") or {}).get("verdict")


def corpus_status(rec: dict[str, Any] | None) -> str:
    """Traité = une validation VLM (ok/corrigée) a été enregistrée dans l'onglet 2.
    Tout le reste (jamais vu, extrait sans validation, anciens verdicts ko/todo)
    reste « non traité »."""
    return "traite" if _vlm_verdict(rec) in VALIDATED_VERDICTS else "non_traite"


def corpus_has_dpo(rec: dict[str, Any] | None) -> bool:
    # Seul le verdict « corrigée » produit une paire DPO ; la projection "lift"
    # sert d'espace canonique (drops confidence-only diffs, same as build_dpo_split).
    if not rec or _vlm_verdict(rec) != "corrected":
        return False
    return dpo_pair(rec.get("validated_json"), rec.get("raw_json"), "lift") is not None


def step_verdict_label(rec: dict[str, Any] | None, step: str) -> str:
    """Avis OK/KO enregistré sur une étape aval ; vide sinon (y compris pour les
    anciens verdicts « todo »)."""
    verdict = (((rec or {}).get("steps") or {}).get(step) or {}).get("verdict")
    return STEP_VERDICT_LABELS.get(verdict, "")


def corpus_row(entry: dict[str, str], rec: dict[str, Any] | None) -> list[str]:
    url = entry["url"]
    collection, doc_type = parse_minio_url(url)
    status = corpus_status(rec)
    traite = status == "traite"
    vlm = ((rec or {}).get("steps") or {}).get("vlm") or {}
    # Les colonnes DPO + étapes restent vides tant que la page n'est pas traitée.
    dpo = ("oui" if corpus_has_dpo(rec) else "non") if traite else ""
    steps = [step_verdict_label(rec, step) if traite else "" for step in CORPUS_STEP_COLUMNS]
    annotator = vlm.get("annotator") or " | ".join((rec or {}).get("annotators") or [])
    return [
        url,
        collection,
        DOC_TYPE_LABELS.get(doc_type, doc_type),
        CORPUS_STATUS_LABELS[status],
        annotator,
        dpo,
        *steps,
    ]


def build_corpus_rows(
    status_filter: str = "tous",
    records: dict[str, dict[str, Any]] | None = None,
) -> tuple[list[list[str]], list[str]]:
    """Return (table rows, urls-in-display-order) for the given status filter."""
    records = records if records is not None else fold_log()
    rows: list[list[str]] = []
    urls: list[str] = []
    for entry in parse_minio_urls_file():
        rec = records.get(entry["url"])
        if status_filter not in (None, "", "tous") and corpus_status(rec) != status_filter:
            continue
        rows.append(corpus_row(entry, rec))
        urls.append(entry["url"])
    return rows, urls


def corpus_counters_html(records: dict[str, dict[str, Any]] | None = None) -> str:
    records = records if records is not None else fold_log()
    entries = parse_minio_urls_file()
    counts = {key: 0 for key in CORPUS_STATUS_LABELS}
    dpo = 0
    for entry in entries:
        rec = records.get(entry["url"])
        counts[corpus_status(rec)] += 1
        if corpus_has_dpo(rec):
            dpo += 1
    total = len(entries)
    tiles = [
        ("Total", total),
        ("Traités", counts["traite"]),
        ("Non traités", counts["non_traite"]),
        ("Paires DPO", dpo),
    ]
    cells = "".join(f"<div><strong>{html.escape(label)}</strong><br>{value}</div>" for label, value in tiles)
    return f"<div class='summary-grid'>{cells}</div>"


def render_corpus_table(rows: list[list[str]]) -> str:
    """Render the corpus as a plain static HTML table. This deliberately replaces
    gr.Dataframe, whose non-virtualised editable grid freezes the browser at a few
    hundred rows; a static table of the same size paints instantly."""
    if not rows:
        return "<p class='muted'>Aucune page pour ce filtre.</p>"
    head = "<th></th>" + "".join(f"<th>{html.escape(h)}</th>" for h in CORPUS_HEADERS)
    body_rows = []
    for row in rows:
        url_attr = html.escape(str(row[0]), quote=True)
        cells = [
            f"<td><button type='button' class='corpus-load-btn' data-url=\"{url_attr}\">Charger</button></td>"
        ]
        for idx, value in enumerate(row):
            text = html.escape(str(value))
            if idx == 0:  # URL column -> link
                cells.append(f"<td><a href='{text}' target='_blank'>{text}</a></td>")
            else:
                cells.append(f"<td>{text}</td>")
        body_rows.append("<tr>" + "".join(cells) + "</tr>")
    return (
        "<div style='max-height:540px;overflow:auto'>"
        f"<table class='data-table'><thead><tr>{head}</tr></thead>"
        f"<tbody>{''.join(body_rows)}</tbody></table></div>"
    )


def refresh_corpus(status_filter: str):
    """Refresh the table (as HTML) + counters + urls state. The gallery is not built
    here (loading full-res MinIO scans is opt-in)."""
    records = fold_log()
    rows, urls = build_corpus_rows(status_filter, records)
    return render_corpus_table(rows), corpus_counters_html(records), urls


def build_corpus_gallery(urls: list[str]) -> list[tuple[str, str]]:
    """Build a capped thumbnail list on demand from the current filtered urls."""
    return [(url, url.split("/images/")[-1]) for url in (urls or [])[:CORPUS_GALLERY_CAP]]


# --------------------------------------------------------------------------
# Chargement d'un document (bouton « Charger » ou vignette) : remise à zéro de
# tous les onglets + restauration de l'avancement journalisé. Le journal ne
# conserve que l'extraction brute, les métadonnées validées et les avis — les
# résultats des services (Sudoc, IdRef, Dewey, brouillon) doivent être relancés.
# --------------------------------------------------------------------------

# Ordre EXACT des sorties de load_doc_into_pipeline — la liste resume_outputs
# d'app.py DOIT le suivre (assert de longueur au démarrage).
RESUME_OUTPUT_ORDER = [
    "image_url", "doc_type", "url_preview", "corpus_select_status",
    "state", "summary",
    "extracted_json", "vlm_raw_json", "vlm_status",
    *METADATA_FIELDS,
    "correction_status", "corrected_json",
    "vlm_verdict", "vlm_remark", "vlm_note_status",
    "sudoc_html", "sudoc_raw_json", "sudoc_candidates", "sudoc_verdict", "sudoc_remark", "sudoc_note_btn", "sudoc_note_status",
    "idref_table", "idref_html", "idref_raw_json", "idref_ppn_status", "idref_verdict", "idref_remark", "idref_note_btn", "idref_note_status",
    "dewey_status", "dewey_choice", "dewey_html", "dewey_raw_json", "dewey_verdict", "dewey_remark", "dewey_note_btn", "dewey_note_status",
    "draft_html", "draft_json", "pipeline_json", "draft_verdict", "draft_remark", "draft_note_btn", "draft_note_status",
]


# Prochaine étape suggérée (clé de reprise -> message de la carte de sélection).
RESUME_MESSAGES = {
    "extract": "Aucun traitement antérieur : commencez par l'onglet « 1. Extraction VLM ».",
    "validate": "Extraction VLM déjà effectuée (restaurée) : reprenez à l'onglet « 2. Métadonnées corrigées » pour valider.",
    "sudoc": "Métadonnées déjà validées (restaurées) : reprenez à l'onglet « 3. Vérification Sudoc ».",
    "idref": "Sudoc déjà noté : reprenez à l'onglet « 4. Alignement IdRef ».",
    "dewey": "IdRef déjà noté : reprenez à l'onglet « 5. Classification Dewey ».",
    "draft": "Dewey déjà noté : reprenez à l'onglet « 6. Brouillon Unimarc ».",
    "done": "Toutes les étapes sont déjà notées pour ce document.",
}


def resume_point(rec: dict[str, Any] | None) -> str:
    """Première étape non faite d'après le journal : extraction manquante ->
    "extract" ; extraction sans validation -> "validate" ; puis premier avis
    manquant parmi les étapes aval ; tout noté -> "done"."""
    if not rec or (not rec.get("last_extraction") and rec.get("raw_json") is None):
        return "extract"
    if _vlm_verdict(rec) not in VALIDATED_VERDICTS:
        return "validate"
    steps = rec.get("steps") or {}
    for step in CORPUS_STEP_COLUMNS:
        if not (steps.get(step) or {}).get("verdict"):
            return step
    return "done"


def _note_suffix(note: dict[str, Any]) -> str:
    who = note.get("annotator") or ""
    when = str(note.get("ts") or "")[:10]
    parts = [p for p in (f"par {who}" if who else "", f"le {when}" if when else "") if p]
    return f" {' '.join(parts)}" if parts else ""


def _step_note_card(step: str, note: dict[str, Any] | None, restored: bool) -> str:
    """Carte de notation au chargement : avis journalisé (avec le rappel adapté
    selon que le résultat de l'étape a pu être restauré ou non), résultat
    restauré non noté (alerte), ou attente."""
    title = f"Notation {STEP_NOTE_LABELS.get(step, step)}"
    verdict = str((note or {}).get("verdict") or "").lower()
    if not verdict:
        if restored:
            return status_card(title, "warn", "Résultat restauré non noté — choisissez OK/KO puis enregistrez votre avis.")
        return status_card(title, "idle", "En attente.")
    label = STEP_VERDICT_LABELS.get(verdict, verdict)
    tone = {"ok": "ok", "ko": "error"}.get(verdict, "idle")
    tail = (
        "Le résultat restauré est affiché ci-dessus." if restored
        else "Résultat non journalisé : relancez l'étape si vous avez besoin de le revoir."
    )
    return status_card(title, tone, f"Avis déjà enregistré : {label}{_note_suffix(note)}. {tail}")


def _restored_note_button(step: str, steps: dict[str, Any], restored: bool):
    """Bouton de notation au chargement : « Ré-enregistrer » si un avis est déjà
    journalisé, alerte « non enregistré » si un résultat restauré attend son
    avis, libellé de base sinon."""
    if (steps.get(step) or {}).get("verdict"):
        return note_button_update(step, "saved")
    return note_button_update(step, "pending" if restored else "idle")


def _vlm_note_card(note: dict[str, Any] | None) -> str:
    verdict = str((note or {}).get("verdict") or "").lower()
    if not verdict:
        return status_card("Validation", "idle", "En attente.")
    if verdict in VALIDATED_VERDICTS:
        label = "correcte" if verdict == "ok" else "corrigée"
        return status_card(
            "Validation", "ok",
            f"Validation déjà enregistrée (extraction {label}){_note_suffix(note)}. "
            "Ré-enregistrez uniquement pour remplacer le verdict.",
        )
    return status_card(
        "Validation", "warn",
        f"Ancien verdict « {verdict} »{_note_suffix(note)} — plus proposé : revalidez l'extraction.",
    )


def load_doc_into_pipeline(
    url: str,
    records: dict[str, dict[str, Any]] | None = None,
    step_records: dict[str, dict[str, Any]] | None = None,
):
    """Charge `url` dans l'onglet 1 en réinitialisant TOUS les onglets, puis
    restaure l'avancement journalisé : extraction brute -> onglets 1-2, JSON
    validé -> formulaire + modules aval, avis par étape -> cartes de statut,
    et derniers résultats Sudoc/IdRef/Dewey/brouillon (step_results.jsonl,
    PPN validés manuellement compris) -> onglets 3-6, sans rappeler les API.
    Retourne les sorties dans l'ordre RESUME_OUTPUT_ORDER."""
    records = records if records is not None else fold_log()
    step_records = step_records if step_records is not None else fold_step_results()
    rec = records.get(url)
    saved = step_records.get(url) or {}
    _, url_doc_type = parse_minio_url(url)
    doc_type = (rec or {}).get("doc_type") or url_doc_type or "these"
    last = (rec or {}).get("last_extraction") or {}
    extracted = last.get("raw_json")
    if extracted is None:
        extracted = (rec or {}).get("raw_json")

    state = empty_state()
    state["input"] = {"doc_type": doc_type, "image_url": url, "image_filename": ""}
    corrected = None
    if extracted is not None:
        # Provenance restaurée : validate_extraction la rejournalise telle quelle.
        state["input"]["provider"] = last.get("provider")
        state["input"]["model"] = last.get("model")
        corrected = normalize_metadata((rec or {}).get("validated_json") or extracted)
        state["vlm"]["extracted"] = extracted
        state["vlm"]["corrected"] = corrected
        state = add_event(state, "vlm", "ok", "Extraction restaurée depuis le journal d'annotations.")

    # Restauration des derniers résultats d'étapes journalisés (step_results.jsonl).
    def _payload(step: str) -> dict[str, Any]:
        return (saved.get(step) or {}).get("payload") or {}

    sudoc_resp = _payload("sudoc").get("response")
    if sudoc_resp:
        state["sudoc"] = {
            "request": _payload("sudoc").get("request"),
            "route": _payload("sudoc").get("route"),
            "response": sudoc_resp,
            "error": None,
        }
        state = add_event(state, "sudoc", "ok", "Résultat Sudoc restauré depuis le journal des résultats.")
    idref_persons = _payload("idref").get("persons") or []
    if idref_persons:
        state["idref"] = {"persons": idref_persons, "settings": _payload("idref").get("settings") or {}, "error": None}
        state = add_event(state, "idref", "ok", "Alignements IdRef restaurés depuis le journal des résultats.")
    dewey_p = _payload("dewey")
    dewey_classes = dewey_p.get("classes") or []
    dewey_selected = dewey_p.get("selected")
    dewey_restored = bool(dewey_classes or dewey_p.get("response"))
    if dewey_restored:
        state["dewey"] = {
            "request": dewey_p.get("request"),
            "response": dewey_p.get("response"),
            "classes": dewey_classes,
            "selected": dewey_selected,
            "error": None,
        }
        state = add_event(state, "dewey", "ok", "Résultat Dewey restauré depuis le journal des résultats.")
    draft = _payload("draft").get("draft")
    if draft:
        state["record_draft"] = draft
        state = add_event(state, "draft", "ok", "Brouillon restauré depuis le journal des résultats.")
    restored = {
        "sudoc": bool(sudoc_resp),
        "idref": bool(idref_persons),
        "dewey": dewey_restored,
        "draft": bool(draft),
    }

    steps = (rec or {}).get("steps") or {}
    # Suivi de notation restauré : verdicts journalisés tels quels ; extraction
    # restaurée sans validation -> "pending" (nag onglet 2 + toast) ; résultat
    # d'étape restauré sans avis -> "pending" également.
    notes = {
        step: (steps.get(step) or {}).get("verdict")
        for step in STEP_TAB_NUMBERS
        if (steps.get(step) or {}).get("verdict")
    }
    if extracted is not None and notes.get("vlm") not in VALIDATED_VERDICTS:
        notes["vlm"] = "pending"
    for step, has_result in restored.items():
        if has_result and not notes.get(step):
            notes[step] = "pending"
    state["notes"] = notes

    point = resume_point(rec)
    select_message = f"URL chargée dans l'onglet 1 : {url}. {RESUME_MESSAGES[point]}"
    restored_labels = (["extraction"] if extracted is not None else []) + [
        STEP_NOTE_LABELS[step] for step in ("sudoc", "idref", "dewey", "draft") if restored[step]
    ]
    if restored_labels:
        select_message += f" Restauré depuis les journaux : {', '.join(restored_labels)}."
    unjournaled = [
        STEP_NOTE_LABELS[step]
        for step in ("sudoc", "idref", "dewey", "draft")
        if (steps.get(step) or {}).get("verdict") and not restored[step]
    ]
    if unjournaled:
        select_message += (
            f" Étape(s) notée(s) sans résultat journalisé (antérieures au journal des "
            f"résultats) : {', '.join(unjournaled)} — relancez-les pour revoir leur résultat."
        )

    if extracted is not None:
        origin = " · ".join(str(x) for x in (last.get("provider"), last.get("model")) if x)
        when = str(last.get("ts") or "")[:10]
        detail = ", ".join(p for p in (origin, when) if p)
        vlm_status = status_card(
            "Extraction VLM", "ok",
            f"Extraction restaurée depuis le journal{f' ({detail})' if detail else ''} — inutile de la relancer.",
        )
    else:
        vlm_status = status_card("Extraction VLM", "idle", "En attente.")

    if idref_persons:
        idref_table_html = render_idref_table(aligned=idref_persons)
        idref_ppn_card = status_card(
            "Validation PPN", "ok",
            "Alignement restauré depuis le journal — vous pouvez valider un PPN directement.",
        )
    else:
        idref_table_html = render_idref_table(people=extract_people(corrected)) if corrected else render_idref_table()
        idref_ppn_card = status_card("Validation PPN", "idle", "Lancez d'abord un alignement.")

    if dewey_restored:
        dewey_resp = dewey_p.get("response") or {}
        dewey_method = dewey_resp.get("method") or (dewey_p.get("request") or {}).get("method")
        if dewey_selected:
            dewey_card = status_card(
                "Classification Dewey", "ok",
                f"Résultat restauré depuis le journal. Classe retenue : "
                f"{dewey_selected.get('code')} — {dewey_selected.get('label')}",
            )
        else:
            dewey_card = status_card("Classification Dewey", "warn", "Résultat restauré — validez une classe.")
        dewey_html_out = render_dewey(dewey_classes, dewey_selected, dewey_method, dewey_resp.get("model"))
        dewey_choice_out = dewey_radio_update(dewey_classes, dewey_selected)
        dewey_raw_out = as_json(dewey_resp) if dewey_resp else ""
    else:
        dewey_card = status_card("Classification Dewey", "idle", "En attente.")
        dewey_html_out = ""
        dewey_choice_out = gr.update(choices=[], value=None)
        dewey_raw_out = ""

    return (
        url,
        doc_type,
        render_image_preview(url),
        status_card("Sélection corpus", "ok", select_message),
        state,
        pipeline_summary(state),
        as_json(extracted) if extracted is not None else "",
        "",
        vlm_status,
        *metadata_to_outputs(corrected or {}),
        status_card("Correction LLM", "idle", "En attente."),
        as_json(corrected) if corrected is not None else "",
        "ok",
        "",
        _vlm_note_card(steps.get("vlm")),
        render_sudoc(sudoc_resp) if sudoc_resp else "",
        as_json(sudoc_resp) if sudoc_resp else "",
        sudoc_candidate_rows(sudoc_resp) if sudoc_resp else [],
        "ok",
        "",
        _restored_note_button("sudoc", steps, restored["sudoc"]),
        _step_note_card("sudoc", steps.get("sudoc"), restored["sudoc"]),
        idref_table_html,
        render_idref(idref_persons) if idref_persons else "",
        as_json(idref_persons) if idref_persons else "",
        idref_ppn_card,
        "ok",
        "",
        _restored_note_button("idref", steps, restored["idref"]),
        _step_note_card("idref", steps.get("idref"), restored["idref"]),
        dewey_card,
        dewey_choice_out,
        dewey_html_out,
        dewey_raw_out,
        "ok",
        "",
        _restored_note_button("dewey", steps, restored["dewey"]),
        _step_note_card("dewey", steps.get("dewey"), restored["dewey"]),
        render_draft(draft) if draft else "",
        as_json(draft) if draft else "",
        as_json(state) if draft else "",
        "ok",
        "",
        _restored_note_button("draft", steps, restored["draft"]),
        _step_note_card("draft", steps.get("draft"), restored["draft"]),
    )


def _resume_noop(message: str):
    """No-op de la même arité que load_doc_into_pipeline (sélection invalide)."""
    return (
        gr.update(),
        gr.update(),
        gr.update(),
        status_card("Sélection corpus", "warn", message),
        *(gr.update() for _ in RESUME_OUTPUT_ORDER[4:]),
    )


def load_picked_url(url: str):
    """Bouton « Charger » du tableau corpus (via le pont JS CORPUS_HEAD) :
    réinitialise les onglets et restaure l'avancement journalisé de l'URL."""
    url = (url or "").strip()
    if not url:
        return _resume_noop("Choisissez une URL dans la liste.")
    return load_doc_into_pipeline(url)


def load_url_from_corpus(urls: list[str], evt: gr.SelectData):
    """Sélection d'une vignette de la galerie : même remise à zéro + restauration
    que le bouton « Charger »."""
    index = evt.index if evt is not None else None
    if isinstance(index, (list, tuple)):
        index = index[0]
    if not urls or index is None or index >= len(urls):
        return _resume_noop("Sélection invalide.")
    return load_doc_into_pipeline(urls[index])


# Delegated click bridge: a "Charger" button in the static HTML corpus table cannot
# call Python directly, so it writes its data-url into the hidden Gradio textbox
# (firing the input event Svelte needs) and clicks the hidden trigger button, whose
# .click handler runs load_picked_url server-side. Installed once via demo.load(js=...).
# Installed via demo.launch(head=...) — a <script> in <head> reliably executes on
# load in Gradio 6 (unlike launch(js=...), whose load-function did not fire here).
# A delegated document click listener catches the per-row "Charger" buttons (added
# dynamically to the static HTML corpus table), stashes the row's data-url in a JS
# global, and clicks the hidden trigger button whose event-js reads that global.
CORPUS_HEAD = """
<script>
(function(){
  if (window.__corpusLoadInstalled) return;
  window.__corpusLoadInstalled = true;
  document.addEventListener('click', function(e){
    var t = e.target;
    var btn = t && t.closest ? t.closest('.corpus-load-btn') : null;
    if (!btn) return;
    e.preventDefault();
    window.__corpusPendingUrl = btn.getAttribute('data-url') || '';
    var trigEl = document.querySelector('#corpus_hidden_btn');
    var trigger = trigEl ? (trigEl.tagName === 'BUTTON' ? trigEl : (trigEl.querySelector('button') || trigEl)) : null;
    if (!trigger) { console.warn('[corpus] trigger not found'); return; }
    trigger.click();
  }, true);
})();
</script>
"""
