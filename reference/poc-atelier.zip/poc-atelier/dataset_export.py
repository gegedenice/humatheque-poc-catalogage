"""Datasets d'entraînement dérivés du journal d'annotations : trois formats SFT
(classic/lift/nuextract), paires DPO auto-dérivées (comparées dans l'espace du
schéma projeté), et export Hugging Face multi-configs. `datasets` est importé
paresseusement dans les fonctions d'export."""

from __future__ import annotations

import html
import json
import os
from io import BytesIO
from typing import Any

import gradio as gr
import requests
from PIL import Image

from annotations import VALIDATED_VERDICTS, fold_log, read_events
from config import EXPORT_IMAGE_MAX_SIZE, MULTIVALUED_FIELDS
from metadata import split_people
from prompts import build_eval_prompt, build_lift_prompt, build_nuextract_template
from render import status_card
from state import as_json


# Field order shared by every SFT target JSON (mirrors the v2 extraction schema,
# minus the non-ground-truth `confidence`).
SFT_TARGET_FIELDS = [
    "title",
    "subtitle",
    "author",
    "degree_type",
    "discipline",
    "volume",
    "granting_institution",
    "co_tutelle_institutions",
    "doctoral_school",
    "defense_year",
    "advisor",
    "jury_president",
    "reviewers",
    "committee_members",
    "language",
]


def sft_target_json(validated: dict[str, Any] | None, fmt: str) -> dict[str, Any]:
    """Project the validated/corrected metadata onto the target schema.
    Convention v2 pour TOUS les formats : champs multivalués en tableaux ([] si
    vide) — split_people absorbe les anciennes chaînes pipe (v1) du journal ;
    `confidence` is excluded."""
    v = validated or {}
    target: dict[str, Any] = {}
    for field in SFT_TARGET_FIELDS:
        value = v.get(field)
        if field in MULTIVALUED_FIELDS:
            target[field] = split_people(value)
        elif value == "":
            target[field] = None
        else:
            target[field] = value
    return target


def sft_prompt(fmt: str, doc_type: str) -> str:
    """The user-turn text for a given format. For NuExtract, instructions + template
    are concatenated so the row stays a self-contained chat-messages example (the
    structured pieces are also carried separately in the row for native serving)."""
    if fmt == "lift":
        return build_lift_prompt(doc_type)
    if fmt == "nuextract":
        parts = build_nuextract_template(doc_type)
        return f"{parts['instructions']}\n\n## Template\n```json\n{parts['template']}\n```"
    return build_eval_prompt(doc_type)


def sft_messages(image_url: str, prompt: str, target: dict[str, Any]) -> list[dict[str, Any]]:
    """Chat-messages pair: user (image + prompt) -> assistant (JSON string). The
    image is referenced by URL here; step 6 embeds the bytes at export time."""
    return [
        {
            "role": "user",
            "content": [
                {"type": "image_url", "image_url": {"url": image_url}},
                {"type": "text", "text": prompt},
            ],
        },
        {"role": "assistant", "content": [{"type": "text", "text": json.dumps(target, ensure_ascii=False)}]},
    ]


def build_sft_split(fmt: str = "lift", records: dict[str, dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    """Build SFT rows for one format from the folded annotation log: only images
    whose VLM verdict is validated ("ok" = extraction correcte telle quelle,
    "corrected" = gold corrigé à la main) with a validated JSON and a real URL."""
    if fmt not in ("classic", "lift", "nuextract"):
        raise gr.Error(f"Format SFT inconnu: {fmt}")
    records = records if records is not None else fold_log()
    rows: list[dict[str, Any]] = []
    for url, rec in records.items():
        vlm = (rec.get("steps") or {}).get("vlm") or {}
        if vlm.get("verdict") not in VALIDATED_VERDICTS or not rec.get("validated_json") or not url:
            continue
        doc_type = rec.get("doc_type") or "these"
        prompt = sft_prompt(fmt, doc_type)
        target = sft_target_json(rec.get("validated_json"), fmt)
        extraction = rec.get("last_extraction") or {}
        row: dict[str, Any] = {
            "image_url": url,
            "collection": rec.get("collection"),
            "doc_type": doc_type,
            "format": fmt,
            "prompt": prompt,
            "messages": sft_messages(url, prompt, target),
            "target": target,
            "annotator": vlm.get("annotator"),
            "provider": extraction.get("provider"),
            "model": extraction.get("model"),
            "correction_provider": vlm.get("correction_provider"),
            "correction_model": vlm.get("correction_model"),
            "ts": vlm.get("ts"),
        }
        if fmt == "nuextract":
            row["chat_template_kwargs"] = build_nuextract_template(doc_type)
        rows.append(row)
    return rows


def dpo_pair(validated: dict[str, Any] | None, raw: dict[str, Any] | None, fmt: str) -> tuple[dict[str, Any], dict[str, Any]] | None:
    """Project both the human-validated JSON and the model's raw extraction onto the
    format schema and return (chosen, rejected) iff they differ. Comparing in the
    projected space (not on the stored dicts) drops non-target noise such as the
    model's `confidence`, so a page only yields a DPO pair on a real correction."""
    if not validated or raw is None:
        return None
    chosen = sft_target_json(validated, fmt)
    rejected = sft_target_json(raw, fmt)
    if chosen == rejected:
        return None
    return chosen, rejected


def build_dpo_split(fmt: str = "lift", records: dict[str, dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    """Build preference rows for one format from the folded log: only images whose
    verdict is "corrected" (a "ok" = extraction correcte ne produit JAMAIS de paire)
    and whose validated JSON differs (in schema space) from the raw extraction. Row
    shape is {prompt, images, chosen, rejected} plus provenance; NuExtract rows also
    carry chat_template_kwargs. chosen/rejected are JSON strings (the assistant target)."""
    if fmt not in ("classic", "lift", "nuextract"):
        raise gr.Error(f"Format DPO inconnu: {fmt}")
    records = records if records is not None else fold_log()
    rows: list[dict[str, Any]] = []
    for url, rec in records.items():
        vlm = (rec.get("steps") or {}).get("vlm") or {}
        if vlm.get("verdict") != "corrected" or not url:
            continue
        pair = dpo_pair(rec.get("validated_json"), rec.get("raw_json"), fmt)
        if pair is None:
            continue
        chosen, rejected = pair
        doc_type = rec.get("doc_type") or "these"
        prompt = sft_prompt(fmt, doc_type)
        extraction = rec.get("last_extraction") or {}
        row: dict[str, Any] = {
            "image_url": url,
            "collection": rec.get("collection"),
            "doc_type": doc_type,
            "format": fmt,
            "prompt": prompt,
            "images": [url],
            "chosen": json.dumps(chosen, ensure_ascii=False),
            "rejected": json.dumps(rejected, ensure_ascii=False),
            "annotator": vlm.get("annotator"),
            "provider": extraction.get("provider"),
            "model": extraction.get("model"),
            "correction_provider": vlm.get("correction_provider"),
            "correction_model": vlm.get("correction_model"),
            "ts": vlm.get("ts"),
        }
        if fmt == "nuextract":
            row["chat_template_kwargs"] = build_nuextract_template(doc_type)
        rows.append(row)
    return rows


# --------------------------------------------------------------------------
# Hugging Face export. Validated notations become one dataset repo with several
# configs: sft_<fmt> and dpo_<fmt> for each of the three prompt flavours, plus a
# "raw" provenance config (the full annotation log). Title-page images are fetched
# from MinIO and embedded as dataset Image bytes so the corpus stays reproducible
# even if MinIO changes; the MinIO URL is kept alongside as provenance.
# --------------------------------------------------------------------------

EXPORT_FORMATS = ["classic", "lift", "nuextract"]


def fetch_export_image(url: str, max_size: int = EXPORT_IMAGE_MAX_SIZE):
    """Fetch and downscale a title-page image for dataset embedding. Returns a PIL
    Image, or None on any failure (the row is kept with image=None + its URL)."""
    try:
        resp = requests.get(url, timeout=15, allow_redirects=True)
        resp.raise_for_status()
        img = Image.open(BytesIO(resp.content))
        img.load()
        if img.mode not in ("RGB", "L"):
            img = img.convert("RGB")
        w, h = img.size
        ratio = min(max_size / w, max_size / h, 1.0)
        if ratio < 1:
            img = img.resize((int(w * ratio), int(h * ratio)), Image.LANCZOS)
        return img
    except Exception:
        return None


def build_hf_datasets(
    formats: list[str],
    include_raw: bool,
    embed_images: bool,
    max_size: int,
    records: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Assemble {config_name: datasets.Dataset}. Nested structures (messages, target)
    are stored as JSON strings for a stable Arrow schema; `image` is an Image feature."""
    from datasets import Dataset, Image as HFImage

    records = records if records is not None else fold_log()
    image_cache: dict[str, Any] = {}

    def image_for(url: str):
        if not embed_images:
            return None
        if url not in image_cache:
            image_cache[url] = fetch_export_image(url, max_size)
        return image_cache[url]

    datasets_out: dict[str, Any] = {}

    for fmt in formats:
        sft_rows = [
            {
                "image": image_for(r["image_url"]),
                "image_url": r["image_url"],
                "collection": r["collection"] or "",
                "doc_type": r["doc_type"],
                "format": fmt,
                "prompt": r["prompt"],
                "messages": json.dumps(r["messages"], ensure_ascii=False),
                "target": json.dumps(r["target"], ensure_ascii=False),
                "annotator": r["annotator"] or "",
                "model": r["model"] or "",
                "provider": r["provider"] or "",
                "correction_provider": r["correction_provider"] or "",
                "correction_model": r["correction_model"] or "",
                "ts": r["ts"] or "",
            }
            for r in build_sft_split(fmt, records)
        ]
        if sft_rows:
            datasets_out[f"sft_{fmt}"] = Dataset.from_list(sft_rows).cast_column("image", HFImage())

        dpo_rows = [
            {
                "image": image_for(r["image_url"]),
                "image_url": r["image_url"],
                "collection": r["collection"] or "",
                "doc_type": r["doc_type"],
                "format": fmt,
                "prompt": r["prompt"],
                "chosen": r["chosen"],
                "rejected": r["rejected"],
                "annotator": r["annotator"] or "",
                "model": r["model"] or "",
                "provider": r["provider"] or "",
                "correction_provider": r["correction_provider"] or "",
                "correction_model": r["correction_model"] or "",
                "ts": r["ts"] or "",
            }
            for r in build_dpo_split(fmt, records)
        ]
        if dpo_rows:
            datasets_out[f"dpo_{fmt}"] = Dataset.from_list(dpo_rows).cast_column("image", HFImage())

    if include_raw:
        raw_rows = [
            {
                "ts": e.get("ts", "") or "",
                "annotator": e.get("annotator", "") or "",
                "image_url": e.get("image_url", "") or "",
                "action": e.get("action", "") or "",
                "step": e.get("step", "") or "",
                "verdict": e.get("verdict", "") or "",
                "remark": e.get("remark", "") or "",
                "doc_type": e.get("doc_type", "") or "",
                "provider": e.get("provider", "") or "",
                "model": e.get("model", "") or "",
                "correction_provider": e.get("correction_provider", "") or "",
                "correction_model": e.get("correction_model", "") or "",
                "prompt": e.get("prompt", "") or "",
                "raw_json": json.dumps(e["raw_json"], ensure_ascii=False) if e.get("raw_json") is not None else "",
                "validated_json": json.dumps(e["validated_json"], ensure_ascii=False) if e.get("validated_json") is not None else "",
            }
            for e in read_events()
        ]
        if raw_rows:
            datasets_out["raw"] = Dataset.from_list(raw_rows)

    return datasets_out


def preview_export(formats: list[str], include_raw: bool) -> tuple[str, str]:
    """Count rows per config and show one SFT sample (minus image bytes). No network:
    only folds the log and runs the split builders."""
    formats = [f for f in (formats or []) if f in EXPORT_FORMATS]
    records = fold_log()
    counts: list[tuple[str, int]] = []
    sample: dict[str, Any] | None = None
    for fmt in formats:
        sft = build_sft_split(fmt, records)
        dpo = build_dpo_split(fmt, records)
        counts.append((f"sft_{fmt}", len(sft)))
        counts.append((f"dpo_{fmt}", len(dpo)))
        if sample is None and sft:
            sample = {k: v for k, v in sft[0].items() if k != "messages"}
    if include_raw:
        counts.append(("raw", len(read_events())))
    rows_html = "".join(
        f"<tr><td><code>{html.escape(name)}</code></td><td><strong>{n}</strong></td></tr>"
        for name, n in counts
    )
    table = (
        "<table class='data-table'><thead><tr><th>Config</th><th>Lignes</th></tr></thead>"
        f"<tbody>{rows_html or '<tr><td colspan=2>Aucune donnée</td></tr>'}</tbody></table>"
    )
    return table, as_json(sample) if sample else "// Aucune extraction validée (OK) pour l'instant."


def push_export_to_hub(
    repo_id: str,
    formats: list[str],
    include_raw: bool,
    private: bool,
    embed_images: bool,
    max_size: int,
) -> str:
    """Build and push every non-empty config into a single HF dataset repo."""
    token = os.getenv("HF_TOKEN", "").strip()
    if not token:
        raise gr.Error("Définissez la variable d'environnement HF_TOKEN pour pousser vers le Hub.")
    repo_id = (repo_id or "").strip()
    if not repo_id:
        raise gr.Error("Renseignez l'identifiant du dépôt (ex. Geraldine/humatheque-vlm-sft).")
    formats = [f for f in (formats or []) if f in EXPORT_FORMATS]
    if not formats and not include_raw:
        raise gr.Error("Sélectionnez au moins un format ou la config brute.")
    datasets_out = build_hf_datasets(formats, include_raw, embed_images, int(max_size))
    if not datasets_out:
        raise gr.Error("Aucune donnée à exporter (aucune extraction validée OK).")
    pushed = []
    for config_name, ds in datasets_out.items():
        ds.push_to_hub(repo_id, config_name=config_name, private=bool(private), token=token)
        pushed.append(f"{config_name} ({ds.num_rows})")
    return status_card("Export Hugging Face", "ok", f"Poussé vers <code>{html.escape(repo_id)}</code> : " + ", ".join(pushed))
