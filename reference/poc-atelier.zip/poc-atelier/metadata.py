"""Normalisation des métadonnées extraites et gestion du formulaire corrigé
(onglet 2) : projection champ↔formulaire, découpage des personnes et rôles.
Convention v2 : les champs multivalués (MULTIVALUED_FIELDS) sont TOUJOURS des
tableaux ([] si vide), affichés et édités en JSON array dans le formulaire."""

from __future__ import annotations

import json
from copy import deepcopy
from typing import Any

from config import METADATA_FIELDS, MULTIVALUED_FIELDS, PERSON_FIELDS
from render import pipeline_summary, render_idref_table
from state import add_event, as_json, empty_state


def coerce_multi(value: Any) -> list[str]:
    """Coerce any model/form value for a multivalued field to a clean list of
    strings. Tolère l'ancienne convention v1 (chaînes « A | B ») pour rester
    compatible avec les extractions déjà journalisées."""
    if value is None or value == "":
        return []
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    return [part.strip() for part in str(value).split("|") if part.strip()]


def normalize_metadata(payload: dict[str, Any]) -> dict[str, Any]:
    normalized = {field: payload.get(field) for field in METADATA_FIELDS}
    # v2 : tableaux partout pour les champs multivalués — même si un modèle
    # renvoie malgré tout une chaîne pipe (v1) ou une valeur scalaire.
    for field in MULTIVALUED_FIELDS:
        normalized[field] = coerce_multi(normalized.get(field))
    # Champs personnes scalaires (author, jury_president) : certains modèles
    # renvoient un tableau — garder le premier nom, None si vide.
    for field in PERSON_FIELDS:
        if field in MULTIVALUED_FIELDS:
            continue
        value = normalized.get(field)
        if isinstance(value, list):
            names = [str(item).strip() for item in value if str(item).strip()]
            normalized[field] = names[0] if names else None
    # volume : chiffre arabe en chaîne (les modèles renvoient parfois un entier).
    if normalized.get("volume") is not None:
        text = str(normalized["volume"]).strip()
        normalized["volume"] = text or None
    return normalized


def metadata_to_outputs(payload: dict[str, Any]) -> tuple[str, ...]:
    values = []
    for field in METADATA_FIELDS:
        value = payload.get(field)
        if field in MULTIVALUED_FIELDS:
            values.append(json.dumps(coerce_multi(value), ensure_ascii=False))
        elif value is None:
            values.append("")
        else:
            values.append(str(value))
    return tuple(values)


def parse_year(value: str) -> int | None:
    value = str(value or "").strip()
    if not value:
        return None
    try:
        return int(value)
    except ValueError:
        return None


def parse_float(value: str) -> float | None:
    value = str(value or "").strip()
    if not value:
        return None
    try:
        return float(value)
    except ValueError:
        return None


def parse_multi_field(value: str) -> list[str]:
    """Parse a multivalued form field: JSON array first (the display format),
    with a pipe-split fallback so a hand-typed « A | B » keeps working."""
    text = str(value or "").strip()
    if not text:
        return []
    try:
        parsed = json.loads(text)
        if isinstance(parsed, list):
            return [str(item).strip() for item in parsed if str(item).strip()]
    except json.JSONDecodeError:
        pass
    return [part.strip() for part in text.split("|") if part.strip()]


def corrected_from_fields(*values: str) -> dict[str, Any]:
    payload = dict(zip(METADATA_FIELDS, values))
    for field in MULTIVALUED_FIELDS:
        payload[field] = parse_multi_field(str(payload.get(field) or ""))
    payload["defense_year"] = parse_year(str(payload.get("defense_year") or ""))
    payload["confidence"] = parse_float(str(payload.get("confidence") or ""))
    for key, value in list(payload.items()):
        if value == "":
            payload[key] = None if key not in MULTIVALUED_FIELDS else []
    return payload


def string_or_empty(value: Any) -> str:
    if value is None:
        return ""
    return str(value)


def update_corrected_metadata(state: dict[str, Any] | None, *values: str) -> tuple[dict[str, Any], str, str, str]:
    """Chaîné après l'extraction (onglet 1) et la correction LLM : reflète le
    formulaire dans state["vlm"]["corrected"], le JSON corrigé, le tableau des
    personnes (onglet 4, HTML statique) et le résumé. La validation humaine passe
    par annotations.validate_extraction (bouton unique de l'onglet 2)."""
    state = deepcopy(state or empty_state())
    corrected = corrected_from_fields(*values)
    state.setdefault("vlm", {})["corrected"] = corrected
    state = add_event(state, "metadata", "ok", "Métadonnées corrigées mises à jour.")
    return state, as_json(corrected), render_idref_table(people=extract_people(corrected)), pipeline_summary(state)


def split_people(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        parts = value
    else:
        parts = str(value).split("|")
    return [str(part).strip() for part in parts if str(part).strip()]


def normalize_name_key(name: str) -> str:
    return " ".join(str(name).lower().split())


def extract_people(payload: dict[str, Any]) -> list[dict[str, Any]]:
    people: dict[str, dict[str, Any]] = {}
    for field in PERSON_FIELDS:
        for name in split_people(payload.get(field)):
            key = normalize_name_key(name)
            if key not in people:
                people[key] = {"name": name, "roles": []}
            if field not in people[key]["roles"]:
                people[key]["roles"].append(field)
    return list(people.values())

